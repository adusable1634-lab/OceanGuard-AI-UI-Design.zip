import { createBrowserRouter } from 'react-router';
import { LoginPage } from './pages/LoginPage';
import { ResidentDashboard } from './pages/ResidentDashboard';
import { RescueDashboard } from './pages/RescueDashboard';
import { ReportHazardPage } from './pages/ReportHazardPage';
import { MapPage } from './pages/MapPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { SettingsPage } from './pages/SettingsPage';
import { NotFoundPage } from './pages/NotFoundPage';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: LoginPage,
  },
  {
    path: '/resident',
    Component: ResidentDashboard,
  },
  {
    path: '/rescue',
    Component: RescueDashboard,
  },
  {
    path: '/report-hazard',
    Component: ReportHazardPage,
  },
  {
    path: '/map',
    Component: MapPage,
  },
  {
    path: '/analytics',
    Component: AnalyticsPage,
  },
  {
    path: '/settings',
    Component: SettingsPage,
  },
  {
    path: '*',
    Component: NotFoundPage,
  },
]);