export interface Incident {
  id: string;
  type: 'sos' | 'hazard';
  hazardType?: 'oilSpill' | 'flood' | 'deadMarineLife' | 'highWaves' | 'pollution';
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'inProgress' | 'resolved';
  location: { lat: number; lng: number; name: string };
  reportedBy: string;
  timestamp: Date;
  description: string;
  imageUrl?: string;
}

export interface Alert {
  id: string;
  type: 'highTide' | 'pollution' | 'weather' | 'evacuation';
  message: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: Date;
  location?: string;
}

export interface SocialMediaPost {
  id: string;
  platform: 'twitter' | 'instagram' | 'facebook';
  content: string;
  mentions: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  location: string;
  timestamp: Date;
  riskScore: number;
}

export interface PredictionData {
  date: string;
  predicted: number;
  actual: number;
}

export const mockIncidents: Incident[] = [
  {
    id: '1',
    type: 'sos',
    severity: 'critical',
    status: 'pending',
    location: { lat: 19.0760, lng: 72.8777, name: 'Mumbai Coastline' },
    reportedBy: 'Rajesh Kumar',
    timestamp: new Date(Date.now() - 5 * 60000),
    description: 'Person drowning near Gateway of India',
  },
  {
    id: '2',
    type: 'hazard',
    hazardType: 'oilSpill',
    severity: 'high',
    status: 'inProgress',
    location: { lat: 18.9217, lng: 72.8347, name: 'Juhu Beach' },
    reportedBy: 'Priya Sharma',
    timestamp: new Date(Date.now() - 30 * 60000),
    description: 'Large oil spill observed near fishing area',
    imageUrl: 'https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?w=400&h=300&fit=crop',
  },
  {
    id: '3',
    type: 'hazard',
    hazardType: 'pollution',
    severity: 'medium',
    status: 'pending',
    location: { lat: 19.1136, lng: 72.9083, name: 'Versova Beach' },
    reportedBy: 'Amit Patel',
    timestamp: new Date(Date.now() - 60 * 60000),
    description: 'Plastic waste accumulation after high tide',
    imageUrl: 'https://images.unsplash.com/photo-1621451537084-482c73073a0f?w=400&h=300&fit=crop',
  },
  {
    id: '4',
    type: 'hazard',
    hazardType: 'highWaves',
    severity: 'high',
    status: 'pending',
    location: { lat: 18.9480, lng: 72.8258, name: 'Bandra Worli Sea Link' },
    reportedBy: 'Sneha Desai',
    timestamp: new Date(Date.now() - 90 * 60000),
    description: 'Unusually high waves threatening infrastructure',
  },
  {
    id: '5',
    type: 'hazard',
    hazardType: 'deadMarineLife',
    severity: 'medium',
    status: 'resolved',
    location: { lat: 19.0330, lng: 72.8480, name: 'Marine Drive' },
    reportedBy: 'Arjun Mehta',
    timestamp: new Date(Date.now() - 120 * 60000),
    description: 'Dead fish found on shoreline',
    imageUrl: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=300&fit=crop',
  },
];

export const mockAlerts: Alert[] = [
  {
    id: '1',
    type: 'highTide',
    message: 'High tide risk in your area',
    severity: 'high',
    timestamp: new Date(Date.now() - 10 * 60000),
    location: 'South Mumbai Coastal Area',
  },
  {
    id: '2',
    type: 'pollution',
    message: 'Pollution detected nearby',
    severity: 'medium',
    timestamp: new Date(Date.now() - 25 * 60000),
    location: 'Juhu Beach',
  },
  {
    id: '3',
    type: 'weather',
    message: 'Severe weather alert - Heavy rainfall expected',
    severity: 'high',
    timestamp: new Date(Date.now() - 45 * 60000),
    location: 'Mumbai Metropolitan Region',
  },
  {
    id: '4',
    type: 'evacuation',
    message: 'Evacuation notice issued for low-lying areas',
    severity: 'high',
    timestamp: new Date(Date.now() - 60 * 60000),
    location: 'Coastal Villages',
  },
];

export const mockSocialMediaPosts: SocialMediaPost[] = [
  {
    id: '1',
    platform: 'twitter',
    content: 'Massive flooding near the coast! Water levels rising rapidly. #MumbaiFloods #Emergency',
    mentions: 1250,
    sentiment: 'negative',
    location: 'Mumbai, Maharashtra',
    timestamp: new Date(Date.now() - 15 * 60000),
    riskScore: 85,
  },
  {
    id: '2',
    platform: 'instagram',
    content: 'Oil spill spotted at Juhu beach. Marine life in danger. Authorities need to act fast! 🚨',
    mentions: 890,
    sentiment: 'negative',
    location: 'Juhu, Mumbai',
    timestamp: new Date(Date.now() - 35 * 60000),
    riskScore: 78,
  },
  {
    id: '3',
    platform: 'twitter',
    content: 'High waves at Marine Drive. Please stay away from the coastline! #Safety',
    mentions: 645,
    sentiment: 'neutral',
    location: 'Marine Drive, Mumbai',
    timestamp: new Date(Date.now() - 50 * 60000),
    riskScore: 65,
  },
  {
    id: '4',
    platform: 'facebook',
    content: 'Coastal cleanup drive successful! Great work by volunteers. Our beaches are safer now.',
    mentions: 432,
    sentiment: 'positive',
    location: 'Versova Beach',
    timestamp: new Date(Date.now() - 90 * 60000),
    riskScore: 20,
  },
  {
    id: '5',
    platform: 'twitter',
    content: 'Weather warning: Cyclone approaching. Fishermen advised not to venture into sea.',
    mentions: 2100,
    sentiment: 'negative',
    location: 'Maharashtra Coast',
    timestamp: new Date(Date.now() - 120 * 60000),
    riskScore: 92,
  },
];

export const mockPredictionData: PredictionData[] = [
  { date: '12 Apr', predicted: 35, actual: 32 },
  { date: '13 Apr', predicted: 42, actual: 45 },
  { date: '14 Apr', predicted: 58, actual: 55 },
  { date: '15 Apr', predicted: 65, actual: 68 },
  { date: '16 Apr', predicted: 72, actual: 70 },
  { date: '17 Apr', predicted: 85, actual: 82 },
  { date: '18 Apr', predicted: 78, actual: 0 },
];

export const mockSentimentData = [
  { name: 'Positive', value: 15, color: '#10b981' },
  { name: 'Neutral', value: 35, color: '#f59e0b' },
  { name: 'Negative', value: 50, color: '#ef4444' },
];

export const mockMentionsOverTime = [
  { time: '00:00', mentions: 120 },
  { time: '04:00', mentions: 85 },
  { time: '08:00', mentions: 245 },
  { time: '12:00', mentions: 380 },
  { time: '16:00', mentions: 520 },
  { time: '20:00', mentions: 450 },
];

export const mockHazardLocations = [
  { id: '1', type: 'oilSpill', lat: 18.9217, lng: 72.8347, severity: 'high' },
  { id: '2', type: 'pollution', lat: 19.1136, lng: 72.9083, severity: 'medium' },
  { id: '3', type: 'highWaves', lat: 18.9480, lng: 72.8258, severity: 'high' },
  { id: '4', type: 'deadMarineLife', lat: 19.0330, lng: 72.8480, severity: 'medium' },
  { id: '5', type: 'sos', lat: 19.0760, lng: 72.8777, severity: 'critical' },
];

export const mockSafeZones = [
  { id: '1', name: 'Safe Zone Alpha', lat: 19.0896, lng: 72.8656 },
  { id: '2', name: 'Safe Zone Beta', lat: 18.9750, lng: 72.8258 },
  { id: '3', name: 'Safe Zone Gamma', lat: 19.0520, lng: 72.8900 },
];

export const mockRescueCenters = [
  { id: '1', name: 'Mumbai Coastal Rescue Center', lat: 19.0144, lng: 72.8479 },
  { id: '2', name: 'Juhu Emergency Station', lat: 19.0983, lng: 72.8267 },
  { id: '3', name: 'Marine Drive Command', lat: 18.9432, lng: 72.8236 },
];
