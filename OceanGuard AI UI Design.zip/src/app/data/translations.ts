export type Language = 'en' | 'hi' | 'mr' | 'ta' | 'bn';

export interface Translations {
  // Common
  appName: string;
  welcome: string;
  logout: string;
  settings: string;
  back: string;
  submit: string;
  cancel: string;
  save: string;
  delete: string;
  edit: string;
  close: string;
  search: string;
  filter: string;
  
  // Login/Auth
  login: string;
  signup: string;
  email: string;
  password: string;
  selectRole: string;
  resident: string;
  rescueTeam: string;
  admin: string;
  loginButton: string;
  signupButton: string;
  welcomeBack: string;
  createAccount: string;
  
  // Resident Dashboard
  home: string;
  sos: string;
  sosButton: string;
  reportHazard: string;
  map: string;
  alerts: string;
  emergencyAlert: string;
  sendSOSAlert: string;
  sosConfirmation: string;
  sosDescription: string;
  
  // Hazard Reporting
  uploadPhoto: string;
  uploadVideo: string;
  voiceInput: string;
  location: string;
  autoDetectLocation: string;
  hazardType: string;
  oilSpill: string;
  flood: string;
  deadMarineLife: string;
  highWaves: string;
  pollution: string;
  description: string;
  submitReport: string;
  reportSubmitted: string;
  
  // Map
  nearbyHazards: string;
  safeZones: string;
  rescueCenters: string;
  liveLocation: string;
  
  // Alerts
  highTideRisk: string;
  pollutionDetected: string;
  weatherAlert: string;
  evacuationNotice: string;
  
  // Rescue Dashboard
  controlPanel: string;
  incidents: string;
  incidentManagement: string;
  sosAlerts: string;
  hazardReports: string;
  assignTeam: string;
  status: string;
  pending: string;
  inProgress: string;
  resolved: string;
  severity: string;
  low: string;
  medium: string;
  high: string;
  critical: string;
  
  // AI Features
  aiCopilot: string;
  askAI: string;
  hazardPrediction: string;
  riskLevel: string;
  predictedRisk: string;
  actualRisk: string;
  anomalyDetection: string;
  socialMediaAnalytics: string;
  imageDetection: string;
  recommendations: string;
  
  // Analytics
  trendingPosts: string;
  sentimentAnalysis: string;
  mentionsOverTime: string;
  riskAnalysis: string;
  dataInsights: string;
  
  // Settings
  language: string;
  notifications: string;
  voiceNavigation: string;
  enableVoice: string;
  theme: string;
  accessibility: string;
  
  // Status Messages
  loading: string;
  noData: string;
  error: string;
  success: string;
  
  // AI Messages
  aiGreeting: string;
  aiHelpMessage: string;
  currentRiskLevel: string;
  suggestRescueAction: string;
  unusualActivity: string;
  highProbabilityFlood: string;
  detectedHazard: string;
  safeEvacuationRoute: string;
  nearestShelter: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    // Common
    appName: 'OceanGuard AI',
    welcome: 'Welcome',
    logout: 'Logout',
    settings: 'Settings',
    back: 'Back',
    submit: 'Submit',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    close: 'Close',
    search: 'Search',
    filter: 'Filter',
    
    // Login/Auth
    login: 'Login',
    signup: 'Sign Up',
    email: 'Email',
    password: 'Password',
    selectRole: 'Select Your Role',
    resident: 'Resident',
    rescueTeam: 'Rescue Team',
    admin: 'Admin',
    loginButton: 'Sign In',
    signupButton: 'Create Account',
    welcomeBack: 'Welcome Back',
    createAccount: 'Create New Account',
    
    // Resident Dashboard
    home: 'Home',
    sos: 'SOS',
    sosButton: 'Emergency SOS',
    reportHazard: 'Report Hazard',
    map: 'Map',
    alerts: 'Alerts',
    emergencyAlert: 'Emergency Alert',
    sendSOSAlert: 'Send SOS Alert',
    sosConfirmation: 'Are you sure you want to send an emergency SOS alert?',
    sosDescription: 'This will notify rescue teams with your live location',
    
    // Hazard Reporting
    uploadPhoto: 'Upload Photo',
    uploadVideo: 'Upload Video',
    voiceInput: 'Voice Input',
    location: 'Location',
    autoDetectLocation: 'Auto-detect Location',
    hazardType: 'Hazard Type',
    oilSpill: 'Oil Spill',
    flood: 'Flood',
    deadMarineLife: 'Dead Marine Life',
    highWaves: 'High Waves',
    pollution: 'Pollution',
    description: 'Description',
    submitReport: 'Submit Report',
    reportSubmitted: 'Report Submitted Successfully',
    
    // Map
    nearbyHazards: 'Nearby Hazards',
    safeZones: 'Safe Zones',
    rescueCenters: 'Rescue Centers',
    liveLocation: 'Live Location',
    
    // Alerts
    highTideRisk: 'High tide risk in your area',
    pollutionDetected: 'Pollution detected nearby',
    weatherAlert: 'Severe weather alert',
    evacuationNotice: 'Evacuation notice issued',
    
    // Rescue Dashboard
    controlPanel: 'Control Panel',
    incidents: 'Incidents',
    incidentManagement: 'Incident Management',
    sosAlerts: 'SOS Alerts',
    hazardReports: 'Hazard Reports',
    assignTeam: 'Assign Team',
    status: 'Status',
    pending: 'Pending',
    inProgress: 'In Progress',
    resolved: 'Resolved',
    severity: 'Severity',
    low: 'Low',
    medium: 'Medium',
    high: 'High',
    critical: 'Critical',
    
    // AI Features
    aiCopilot: 'AI Copilot',
    askAI: 'Ask AI Assistant',
    hazardPrediction: 'Hazard Prediction',
    riskLevel: 'Risk Level',
    predictedRisk: 'Predicted Risk',
    actualRisk: 'Actual Risk',
    anomalyDetection: 'Anomaly Detection',
    socialMediaAnalytics: 'Social Media Analytics',
    imageDetection: 'Image Detection',
    recommendations: 'Recommendations',
    
    // Analytics
    trendingPosts: 'Trending Posts',
    sentimentAnalysis: 'Sentiment Analysis',
    mentionsOverTime: 'Mentions Over Time',
    riskAnalysis: 'Risk Analysis',
    dataInsights: 'Data Insights',
    
    // Settings
    language: 'Language',
    notifications: 'Notifications',
    voiceNavigation: 'Voice Navigation',
    enableVoice: 'Enable Voice',
    theme: 'Theme',
    accessibility: 'Accessibility',
    
    // Status Messages
    loading: 'Loading...',
    noData: 'No data available',
    error: 'Error occurred',
    success: 'Success',
    
    // AI Messages
    aiGreeting: 'Hello! I\'m your AI assistant. How can I help you today?',
    aiHelpMessage: 'I can help you with risk assessment, rescue coordination, and safety recommendations.',
    currentRiskLevel: 'Current risk level in your area is',
    suggestRescueAction: 'Suggested rescue action',
    unusualActivity: 'Unusual activity detected in coastal area',
    highProbabilityFlood: 'High probability of flood based on social activity',
    detectedHazard: 'Detected',
    safeEvacuationRoute: 'Safe evacuation route',
    nearestShelter: 'Nearest shelter',
  },
  
  hi: {
    // Common
    appName: 'ओशनगार्ड AI',
    welcome: 'स्वागत है',
    logout: 'लॉग आउट',
    settings: 'सेटिंग्स',
    back: 'वापस',
    submit: 'जमा करें',
    cancel: 'रद्द करें',
    save: 'सहेजें',
    delete: 'हटाएं',
    edit: 'संपादित करें',
    close: 'बंद करें',
    search: 'खोजें',
    filter: 'फ़िल्टर',
    
    // Login/Auth
    login: 'लॉग इन',
    signup: 'साइन अप',
    email: 'ईमेल',
    password: 'पासवर्ड',
    selectRole: 'अपनी भूमिका चुनें',
    resident: 'निवासी',
    rescueTeam: 'बचाव दल',
    admin: 'प्रशासक',
    loginButton: 'साइन इन करें',
    signupButton: 'खाता बनाएं',
    welcomeBack: 'वापसी पर स्वागत है',
    createAccount: 'नया खाता बनाएं',
    
    // Resident Dashboard
    home: 'होम',
    sos: 'एसओएस',
    sosButton: 'आपातकालीन SOS',
    reportHazard: 'खतरे की रिपोर्ट करें',
    map: 'नक्शा',
    alerts: 'अलर्ट',
    emergencyAlert: 'आपातकालीन चेतावनी',
    sendSOSAlert: 'SOS अलर्ट भेजें',
    sosConfirmation: 'क्या आप वाकई आपातकालीन SOS अलर्ट भेजना चाहते हैं?',
    sosDescription: 'यह आपके लाइव स्थान के साथ बचाव दलों को सूचित करेगा',
    
    // Hazard Reporting
    uploadPhoto: 'फोटो अपलोड करें',
    uploadVideo: 'वीडियो अपलोड करें',
    voiceInput: 'वॉयस इनपुट',
    location: 'स्थान',
    autoDetectLocation: 'स्थान स्वतः पता करें',
    hazardType: 'खतरे का प्रकार',
    oilSpill: 'तेल रिसाव',
    flood: 'बाढ़',
    deadMarineLife: 'मृत समुद्री जीवन',
    highWaves: 'ऊंची लहरें',
    pollution: 'प्रदूषण',
    description: 'विवरण',
    submitReport: 'रिपोर्ट जमा करें',
    reportSubmitted: 'रिपोर्ट सफलतापूर्वक जमा की गई',
    
    // Map
    nearbyHazards: 'आस-पास के खतरे',
    safeZones: 'सुरक्षित क्षेत्र',
    rescueCenters: 'बचाव केंद्र',
    liveLocation: 'लाइव स्थान',
    
    // Alerts
    highTideRisk: 'आपके क्षेत्र में उच्च ज्वार का खतरा',
    pollutionDetected: 'पास में प्रदूषण का पता चला',
    weatherAlert: 'गंभीर मौसम चेतावनी',
    evacuationNotice: 'निकासी नोटिस जारी',
    
    // Rescue Dashboard
    controlPanel: 'नियंत्रण कक्ष',
    incidents: 'घटनाएं',
    incidentManagement: 'घटना प्रबंधन',
    sosAlerts: 'SOS अलर्ट',
    hazardReports: 'खतरे की रिपोर्ट',
    assignTeam: 'टीम असाइन करें',
    status: 'स्थिति',
    pending: 'लंबित',
    inProgress: 'प्रगति में',
    resolved: 'हल हो गया',
    severity: 'गंभीरता',
    low: 'कम',
    medium: 'मध्यम',
    high: 'उच्च',
    critical: 'गंभीर',
    
    // AI Features
    aiCopilot: 'AI सहायक',
    askAI: 'AI सहायक से पूछें',
    hazardPrediction: 'खतरे की भविष्यवाणी',
    riskLevel: 'जोखिम स्तर',
    predictedRisk: 'अनुमानित जोखिम',
    actualRisk: 'वास्तविक जोखिम',
    anomalyDetection: 'विसंगति का पता लगाना',
    socialMediaAnalytics: 'सोशल मीडिया विश्लेषण',
    imageDetection: 'छवि पहचान',
    recommendations: 'सिफारिशें',
    
    // Analytics
    trendingPosts: 'ट्रेंडिंग पोस्ट',
    sentimentAnalysis: 'भावना विश्लेषण',
    mentionsOverTime: 'समय के साथ उल्लेख',
    riskAnalysis: 'जोखिम विश्लेषण',
    dataInsights: 'डेटा अंतर्दृष्टि',
    
    // Settings
    language: 'भाषा',
    notifications: 'सूचनाएं',
    voiceNavigation: 'वॉयस नेविगेशन',
    enableVoice: 'वॉयस सक्षम करें',
    theme: 'थीम',
    accessibility: 'पहुँच',
    
    // Status Messages
    loading: 'लोड हो रहा है...',
    noData: 'कोई डेटा उपलब्ध नहीं',
    error: 'त्रुटि हुई',
    success: 'सफलता',
    
    // AI Messages
    aiGreeting: 'नमस्ते! मैं आपका AI सहायक हूं। मैं आज आपकी कैसे मदद कर सकता हूं?',
    aiHelpMessage: 'मैं जोखिम मूल्यांकन, बचाव समन्वय और सुरक्षा सिफारिशों में आपकी मदद कर सकता हूं।',
    currentRiskLevel: 'आपके क्षेत्र में वर्तमान जोखिम स्तर है',
    suggestRescueAction: 'सुझाई गई बचाव कार्रवाई',
    unusualActivity: 'तटीय क्षेत्र में असामान्य गतिविधि का पता चला',
    highProbabilityFlood: 'सोशल गतिविधि के आधार पर बाढ़ की उच्च संभावना',
    detectedHazard: 'पहचाना गया',
    safeEvacuationRoute: 'सुरक्षित निकासी मार्ग',
    nearestShelter: 'निकटतम आश्रय',
  },
  
  mr: {
    // Common
    appName: 'ओशनगार्ड AI',
    welcome: 'स्वागत आहे',
    logout: 'लॉग आउट',
    settings: 'सेटिंग्ज',
    back: 'मागे',
    submit: 'सबमिट करा',
    cancel: 'रद्द करा',
    save: 'जतन करा',
    delete: 'हटवा',
    edit: 'संपादित करा',
    close: 'बंद करा',
    search: 'शोधा',
    filter: 'फिल्टर',
    
    // Login/Auth
    login: 'लॉग इन',
    signup: 'साइन अप',
    email: 'ईमेल',
    password: 'पासवर्ड',
    selectRole: 'तुमची भूमिका निवडा',
    resident: 'रहिवासी',
    rescueTeam: 'बचाव पथक',
    admin: 'प्रशासक',
    loginButton: 'साइन इन करा',
    signupButton: 'खाते तयार करा',
    welcomeBack: 'पुन्हा स्वागत आहे',
    createAccount: 'नवीन खाते तयार करा',
    
    // Resident Dashboard
    home: 'होम',
    sos: 'एसओएस',
    sosButton: 'आणीबाणीचा SOS',
    reportHazard: 'धोक्याची तक्रार करा',
    map: 'नकाशा',
    alerts: 'सूचना',
    emergencyAlert: 'आणीबाणीची सूचना',
    sendSOSAlert: 'SOS सूचना पाठवा',
    sosConfirmation: 'तुम्हाला खरोखर आणीबाणीचा SOS अलर्ट पाठवायचा आहे का?',
    sosDescription: 'हे तुमच्या थेट स्थानासह बचाव पथकांना सूचित करेल',
    
    // Hazard Reporting
    uploadPhoto: 'फोटो अपलोड करा',
    uploadVideo: 'व्हिडिओ अपलोड करा',
    voiceInput: 'व्हॉइस इनपुट',
    location: 'स्थान',
    autoDetectLocation: 'स्थान स्वयं-शोधा',
    hazardType: 'धोक्याचा प्रकार',
    oilSpill: 'तेल गळती',
    flood: 'पूर',
    deadMarineLife: 'मृत सागरी जीवन',
    highWaves: 'उंच लाटा',
    pollution: 'प्रदूषण',
    description: 'वर्णन',
    submitReport: 'अहवाल सबमिट करा',
    reportSubmitted: 'अहवाल यशस्वीरित्या सबमिट झाला',
    
    // Map
    nearbyHazards: 'जवळपासचे धोके',
    safeZones: 'सुरक्षित क्षेत्रे',
    rescueCenters: 'बचाव केंद्रे',
    liveLocation: 'थेट स्थान',
    
    // Alerts
    highTideRisk: 'तुमच्या क्षेत्रात उच्च भरतीचा धोका',
    pollutionDetected: 'जवळपास प्रदूषण आढळले',
    weatherAlert: 'गंभीर हवामान सूचना',
    evacuationNotice: 'बाहेर काढण्याची सूचना जारी',
    
    // Rescue Dashboard
    controlPanel: 'नियंत्रण कक्ष',
    incidents: 'घटना',
    incidentManagement: 'घटना व्यवस्थापन',
    sosAlerts: 'SOS सूचना',
    hazardReports: 'धोक्याचे अहवाल',
    assignTeam: 'टीम नेमा',
    status: 'स्थिती',
    pending: 'प्रलंबित',
    inProgress: 'प्रगतीपथावर',
    resolved: 'निराकरण झाले',
    severity: 'तीव्रता',
    low: 'कमी',
    medium: 'मध्यम',
    high: 'उच्च',
    critical: 'गंभीर',
    
    // AI Features
    aiCopilot: 'AI सहाय्यक',
    askAI: 'AI सहाय्यकाला विचारा',
    hazardPrediction: 'धोक्याचा अंदाज',
    riskLevel: 'जोखीम पातळी',
    predictedRisk: 'अंदाजित जोखीम',
    actualRisk: 'वास्तविक जोखीम',
    anomalyDetection: 'विसंगती शोध',
    socialMediaAnalytics: 'सोशल मीडिया विश्लेषण',
    imageDetection: 'प्रतिमा ओळख',
    recommendations: 'शिफारसी',
    
    // Analytics
    trendingPosts: 'ट्रेंडिंग पोस्ट',
    sentimentAnalysis: 'भावना विश्लेषण',
    mentionsOverTime: 'कालांतराने उल्लेख',
    riskAnalysis: 'जोखीम विश्लेषण',
    dataInsights: 'डेटा अंतर्दृष्टी',
    
    // Settings
    language: 'भाषा',
    notifications: 'सूचना',
    voiceNavigation: 'व्हॉइस नेव्हिगेशन',
    enableVoice: 'व्हॉइस सक्षम करा',
    theme: 'थीम',
    accessibility: 'प्रवेशयोग्यता',
    
    // Status Messages
    loading: 'लोड होत आहे...',
    noData: 'डेटा उपलब्ध नाही',
    error: 'त्रुटी आली',
    success: 'यशस्वी',
    
    // AI Messages
    aiGreeting: 'नमस्कार! मी तुमचा AI सहाय्यक आहे. आज मी तुम्हाला कशी मदत करू शकतो?',
    aiHelpMessage: 'मी जोखीम मूल्यांकन, बचाव समन्वय आणि सुरक्षा शिफारशींमध्ये तुम्हाला मदत करू शकतो.',
    currentRiskLevel: 'तुमच्या क्षेत्रातील सध्याची जोखीम पातळी आहे',
    suggestRescueAction: 'सुचवलेली बचाव कृती',
    unusualActivity: 'किनारी भागात असामान्य क्रियाकलाप आढळला',
    highProbabilityFlood: 'सोशल क्रियाकलापावर आधारित पुराची उच्च संभाव्यता',
    detectedHazard: 'आढळले',
    safeEvacuationRoute: 'सुरक्षित बाहेर काढण्याचा मार्ग',
    nearestShelter: 'जवळचा आश्रय',
  },
  
  ta: {
    // Common
    appName: 'ஓஷன்கார்ட் AI',
    welcome: 'வரவேற்கிறோம்',
    logout: 'வெளியேறு',
    settings: 'அமைப்புகள்',
    back: 'பின்',
    submit: 'சமர்ப்பிக்கவும்',
    cancel: 'ரத்து செய்',
    save: 'சேமி',
    delete: 'நீக்கு',
    edit: 'திருத்து',
    close: 'மூடு',
    search: 'தேடு',
    filter: 'வடிகட்டி',
    
    // Login/Auth
    login: 'உள்நுழைய',
    signup: 'பதிவு செய்க',
    email: 'மின்னஞ்சல்',
    password: 'கடவுச்சொல்',
    selectRole: 'உங்கள் பங்கைத் தேர்ந்தெடுக்கவும்',
    resident: 'குடியிருப்பாளர்',
    rescueTeam: 'மீட்புக் குழு',
    admin: 'நிர்வாகி',
    loginButton: 'உள்நுழைக',
    signupButton: 'கணக்கை உருவாக்கு',
    welcomeBack: 'மீண்டும் வரவேற்கிறோம்',
    createAccount: 'புதிய கணக்கை உருவாக்கு',
    
    // Resident Dashboard
    home: 'முகப்பு',
    sos: 'எஸ்ஓஎஸ்',
    sosButton: 'அவசர SOS',
    reportHazard: 'ஆபத்தை அறிவிக்கவும்',
    map: 'வரைபடம்',
    alerts: 'எச்சரிக்கைகள்',
    emergencyAlert: 'அவசர எச்சரிக்கை',
    sendSOSAlert: 'SOS எச்சரிக்கையை அனுப்பவும்',
    sosConfirmation: 'நீங்கள் உண்மையில் அவசர SOS எச்சரிக்கையை அனுப்ப விரும்புகிறீர்களா?',
    sosDescription: 'இது உங்கள் நேரடி இருப்பிடத்துடன் மீட்புக் குழுக்களுக்கு அறிவிக்கும்',
    
    // Hazard Reporting
    uploadPhoto: 'புகைப்படம் பதிவேற்றவும்',
    uploadVideo: 'வீடியோவை பதிவேற்றவும்',
    voiceInput: 'குரல் உள்ளீடு',
    location: 'இருப்பிடம்',
    autoDetectLocation: 'தானாக இருப்பிடத்தைக் கண்டறியவும்',
    hazardType: 'ஆபத்து வகை',
    oilSpill: 'எண்ணெய் கசிவு',
    flood: 'வெள்ளம்',
    deadMarineLife: 'இறந்த கடல் உயிரினங்கள்',
    highWaves: 'உயர் அலைகள்',
    pollution: 'மாசுபாடு',
    description: 'விவரம்',
    submitReport: 'அறிக்கையை சமர்ப்பிக்கவும்',
    reportSubmitted: 'அறிக்கை வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது',
    
    // Map
    nearbyHazards: 'அருகிலுள்ள ஆபத்துகள்',
    safeZones: 'பாதுகாப்பான பகுதிகள்',
    rescueCenters: 'மீட்பு மையங்கள்',
    liveLocation: 'நேரடி இருப்பிடம்',
    
    // Alerts
    highTideRisk: 'உங்கள் பகுதியில் அதிக அலை ஆபத்து',
    pollutionDetected: 'அருகில் மாசுபாடு கண்டறியப்பட்டது',
    weatherAlert: 'கடுமையான வானிலை எச்சரிக்கை',
    evacuationNotice: 'வெளியேற்ற அறிவிப்பு வெளியிடப்பட்டது',
    
    // Rescue Dashboard
    controlPanel: 'கட்டுப்பாட்டு பலகை',
    incidents: 'சம்பவங்கள்',
    incidentManagement: 'சம்பவ நிர்வாகம்',
    sosAlerts: 'SOS எச்சரிக்கைகள்',
    hazardReports: 'ஆபத்து அறிக்கைகள்',
    assignTeam: 'குழுவை ஒதுக்கவும்',
    status: 'நிலை',
    pending: 'நிலுவையில்',
    inProgress: 'முன்னேற்றத்தில்',
    resolved: 'தீர்க்கப்பட்டது',
    severity: 'தீவிரம்',
    low: 'குறைவு',
    medium: 'நடுத்தரம்',
    high: 'உயர்',
    critical: 'முக்கியமான',
    
    // AI Features
    aiCopilot: 'AI உதவியாளர்',
    askAI: 'AI உதவியாளரிடம் கேளுங்கள்',
    hazardPrediction: 'ஆபத்து கணிப்பு',
    riskLevel: 'ஆபத்து நிலை',
    predictedRisk: 'கணிக்கப்பட்ட ஆபத்து',
    actualRisk: 'உண்மையான ஆபத்து',
    anomalyDetection: 'ஒழுங்கின்மை கண்டறிதல்',
    socialMediaAnalytics: 'சமூக ஊடக பகுப்பாய்வு',
    imageDetection: 'படம் கண்டறிதல்',
    recommendations: 'பரிந்துரைகள்',
    
    // Analytics
    trendingPosts: 'டிரெண்டிங் இடுகைகள்',
    sentimentAnalysis: 'உணர்வு பகுப்பாய்வு',
    mentionsOverTime: 'காலப்போக்கில் குறிப்புகள்',
    riskAnalysis: 'ஆபத்து பகுப்பாய்வு',
    dataInsights: 'தரவு நுண்ணறிவு',
    
    // Settings
    language: 'மொழி',
    notifications: 'அறிவிப்புகள்',
    voiceNavigation: 'குரல் வழிசெலுத்தல்',
    enableVoice: 'குரலை இயக்கு',
    theme: 'தீம்',
    accessibility: 'அணுகல்',
    
    // Status Messages
    loading: 'ஏற்றுகிறது...',
    noData: 'தரவு எதுவும் இல்லை',
    error: 'பிழை ஏற்பட்டது',
    success: 'வெற்றி',
    
    // AI Messages
    aiGreeting: 'வணக்கம்! நான் உங்கள் AI உதவியாளர். இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?',
    aiHelpMessage: 'நான் ஆபத்து மதிப்பீடு, மீட்பு ஒருங்கிணைப்பு மற்றும் பாதுகாப்பு பரிந்துரைகளில் உங்களுக்கு உதவ முடியும்.',
    currentRiskLevel: 'உங்கள் பகுதியில் தற்போதைய ஆபத்து நிலை',
    suggestRescueAction: 'பரிந்துரைக்கப்பட்ட மீட்பு நடவடிக்கை',
    unusualActivity: 'கடலோர பகுதியில் அசாதாரண செயல்பாடு கண்டறியப்பட்டது',
    highProbabilityFlood: 'சமூக செயல்பாட்டின் அடிப்படையில் வெள்ளத்தின் அதிக நிகழ்தகவு',
    detectedHazard: 'கண்டறியப்பட்டது',
    safeEvacuationRoute: 'பாதுகாப்பான வெளியேற்ற பாதை',
    nearestShelter: 'அருகிலுள்ள தங்குமிடம்',
  },
  
  bn: {
    // Common
    appName: 'ওশানগার্ড AI',
    welcome: 'স্বাগতম',
    logout: 'লগ আউট',
    settings: 'সেটিংস',
    back: 'পেছনে',
    submit: 'জমা দিন',
    cancel: 'বাতিল',
    save: 'সংরক্ষণ',
    delete: 'মুছুন',
    edit: 'সম্পাদনা',
    close: 'বন্ধ',
    search: 'খুঁজুন',
    filter: 'ফিল্টার',
    
    // Login/Auth
    login: 'লগ ইন',
    signup: 'সাইন আপ',
    email: 'ইমেইল',
    password: 'পাসওয়ার্ড',
    selectRole: 'আপনার ভূমিকা নির্বাচন করুন',
    resident: 'বাসিন্দা',
    rescueTeam: 'উদ্ধার দল',
    admin: 'প্রশাসক',
    loginButton: 'সাইন ইন করুন',
    signupButton: 'অ্যাকাউন্ট তৈরি করুন',
    welcomeBack: 'আবার স্বাগতম',
    createAccount: 'নতুন অ্যাকাউন্ট তৈরি করুন',
    
    // Resident Dashboard
    home: 'হোম',
    sos: 'এসওএস',
    sosButton: 'জরুরী SOS',
    reportHazard: 'বিপদ রিপোর্ট করুন',
    map: 'মানচিত্র',
    alerts: 'সতর্কতা',
    emergencyAlert: 'জরুরী সতর্কতা',
    sendSOSAlert: 'SOS সতর্কতা পাঠান',
    sosConfirmation: 'আপনি কি নিশ্চিত যে আপনি একটি জরুরী SOS সতর্কতা পাঠাতে চান?',
    sosDescription: 'এটি আপনার লাইভ অবস্থান সহ উদ্ধার দলগুলিকে অবহিত করবে',
    
    // Hazard Reporting
    uploadPhoto: 'ফটো আপলোড করুন',
    uploadVideo: 'ভিডিও আপলোড করুন',
    voiceInput: 'ভয়েস ইনপুট',
    location: 'অবস্থান',
    autoDetectLocation: 'স্বয়ংক্রিয়ভাবে অবস্থান সনাক্ত করুন',
    hazardType: 'বিপদের ধরন',
    oilSpill: 'তেল ছড়িয়ে পড়া',
    flood: 'বন্যা',
    deadMarineLife: 'মৃত সামুদ্রিক জীবন',
    highWaves: 'উচ্চ ঢেউ',
    pollution: 'দূষণ',
    description: 'বিবরণ',
    submitReport: 'রিপোর্ট জমা দিন',
    reportSubmitted: 'রিপোর্ট সফলভাবে জমা দেওয়া হয়েছে',
    
    // Map
    nearbyHazards: 'কাছাকাছি বিপদ',
    safeZones: 'নিরাপদ অঞ্চল',
    rescueCenters: 'উদ্ধার কেন্দ্র',
    liveLocation: 'লাইভ অবস্থান',
    
    // Alerts
    highTideRisk: 'আপনার এলাকায় উচ্চ জোয়ারের ঝুঁকি',
    pollutionDetected: 'কাছাকাছি দূষণ সনাক্ত করা হয়েছে',
    weatherAlert: 'গুরুতর আবহাওয়া সতর্কতা',
    evacuationNotice: 'সরিয়ে নেওয়ার নোটিশ জারি করা হয়েছে',
    
    // Rescue Dashboard
    controlPanel: 'নিয়ন্ত্রণ প্যানেল',
    incidents: 'ঘটনা',
    incidentManagement: 'ঘটনা ব্যবস্থাপনা',
    sosAlerts: 'SOS সতর্কতা',
    hazardReports: 'বিপদ রিপোর্ট',
    assignTeam: 'দল নিয়োগ করুন',
    status: 'অবস্থা',
    pending: 'মুলতুবি',
    inProgress: 'চলছে',
    resolved: 'সমাধান হয়েছে',
    severity: 'তীব্রতা',
    low: 'কম',
    medium: 'মাঝারি',
    high: 'উচ্চ',
    critical: 'সমালোচনামূলক',
    
    // AI Features
    aiCopilot: 'AI সহায়ক',
    askAI: 'AI সহায়ককে জিজ্ঞাসা করুন',
    hazardPrediction: 'বিপদ পূর্বাভাস',
    riskLevel: 'ঝুঁকির স্তর',
    predictedRisk: 'পূর্বাভাসিত ঝুঁকি',
    actualRisk: 'প্রকৃত ঝুঁকি',
    anomalyDetection: 'অসংগতি সনাক্তকরণ',
    socialMediaAnalytics: 'সোশ্যাল মিডিয়া বিশ্লেষণ',
    imageDetection: 'ছবি সনাক্তকরণ',
    recommendations: 'সুপারিশ',
    
    // Analytics
    trendingPosts: 'ট্রেন্ডিং পোস্ট',
    sentimentAnalysis: 'অনুভূতি বিশ্লেষণ',
    mentionsOverTime: 'সময়ের সাথে উল্লেখ',
    riskAnalysis: 'ঝুঁকি বিশ্লেষণ',
    dataInsights: 'ডেটা অন্তর্দৃষ্টি',
    
    // Settings
    language: 'ভাষা',
    notifications: 'বিজ্ঞপ্তি',
    voiceNavigation: 'ভয়েস নেভিগেশন',
    enableVoice: 'ভয়েস সক্ষম করুন',
    theme: 'থিম',
    accessibility: 'অ্যাক্সেসযোগ্যতা',
    
    // Status Messages
    loading: 'লোড হচ্ছে...',
    noData: 'কোন ডেটা উপলব্ধ নেই',
    error: 'ত্রুটি ঘটেছে',
    success: 'সফল',
    
    // AI Messages
    aiGreeting: 'হ্যালো! আমি আপনার AI সহায়ক। আজ আমি আপনাকে কীভাবে সাহায্য করতে পারি?',
    aiHelpMessage: 'আমি ঝুঁকি মূল্যায়ন, উদ্ধার সমন্বয় এবং নিরাপত্তা সুপারিশে আপনাকে সাহায্য করতে পারি।',
    currentRiskLevel: 'আপনার এলাকায় বর্তমান ঝুঁকির স্তর হল',
    suggestRescueAction: 'প্রস্তাবিত উদ্ধার পদক্ষেপ',
    unusualActivity: 'উপকূলীয় এলাকায় অস্বাভাবিক কার্যকলাপ সনাক্ত করা হয়েছে',
    highProbabilityFlood: 'সামাজিক কার্যকলাপের ভিত্তিতে বন্যার উচ্চ সম্ভাবনা',
    detectedHazard: 'সনাক্ত করা হয়েছে',
    safeEvacuationRoute: 'নিরাপদ সরিয়ে নেওয়ার রুট',
    nearestShelter: 'নিকটতম আশ্রয়',
  },
};

export const languageNames: Record<Language, string> = {
  en: 'English',
  hi: 'हिंदी',
  mr: 'मराठी',
  ta: 'தமிழ்',
  bn: 'বাংলা',
};
