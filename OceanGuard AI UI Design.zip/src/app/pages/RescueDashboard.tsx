import { useState } from 'react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import {
  Shield,
  AlertCircle,
  MapPin,
  Activity,
  TrendingUp,
  LogOut,
  MessageSquare,
  BarChart3,
  Users,
  Clock,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { LanguageSelector } from '../components/LanguageSelector';
import { AICopilot } from '../components/AICopilot';
import { IncidentCard } from '../components/IncidentCard';
import { RiskMeter } from '../components/RiskMeter';
import { LiveMap } from '../components/LiveMap';
import { mockIncidents } from '../data/mockData';

export function RescueDashboard() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [showAI, setShowAI] = useState(false);

  const stats = [
    {
      label: t.sosAlerts,
      value: mockIncidents.filter((i) => i.type === 'sos').length,
      icon: AlertCircle,
      gradient: 'from-red-500 to-pink-500',
      change: '+2',
    },
    {
      label: t.hazardReports,
      value: mockIncidents.filter((i) => i.type === 'hazard').length,
      icon: MapPin,
      gradient: 'from-orange-500 to-yellow-500',
      change: '+4',
    },
    {
      label: t.inProgress,
      value: mockIncidents.filter((i) => i.status === 'inProgress').length,
      icon: Activity,
      gradient: 'from-blue-500 to-cyan-500',
      change: '+1',
    },
    {
      label: t.resolved,
      value: mockIncidents.filter((i) => i.status === 'resolved').length,
      icon: TrendingUp,
      gradient: 'from-green-500 to-teal-500',
      change: '+3',
    },
  ];

  const pendingIncidents = mockIncidents.filter((i) => i.status === 'pending');
  const activeIncidents = mockIncidents.filter((i) => i.status === 'inProgress');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      {/* Header */}
      <header className="bg-white/70 backdrop-blur-xl border-b border-white/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-teal-400 blur-lg opacity-50" />
                <Shield className="w-8 h-8 text-blue-600 relative z-10" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{t.appName}</h1>
                <p className="text-sm text-gray-600">{t.rescueTeam} {t.controlPanel}</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                onClick={() => navigate('/analytics')}
                className="hidden md:flex"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                {t.socialMediaAnalytics}
              </Button>
              <LanguageSelector />
              <Button variant="ghost" onClick={() => navigate('/')} className="text-gray-600">
                <LogOut className="w-4 h-4 mr-2" />
                {t.logout}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Stats Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20 relative overflow-hidden group hover:shadow-lg transition-shadow duration-300">
                  <div
                    className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${stat.gradient} opacity-10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500`}
                  />
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-2">
                      <div
                        className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.gradient} flex items-center justify-center`}
                      >
                        <stat.icon className="w-6 h-6 text-white" />
                      </div>
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        {stat.change}
                      </Badge>
                    </div>
                    <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Risk Analysis */}
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1 p-6 bg-white/70 backdrop-blur-sm border border-white/20">
              <h3 className="text-lg font-bold text-gray-900 mb-4">{t.riskLevel}</h3>
              <RiskMeter level={72} />
            </Card>

            <Card className="lg:col-span-2 p-6 bg-white/70 backdrop-blur-sm border border-white/20">
              <h3 className="text-lg font-bold text-gray-900 mb-4">
                {t.hazardPrediction}
              </h3>
              <div className="space-y-3">
                <div className="p-4 bg-gradient-to-r from-red-50 to-orange-50 rounded-lg border border-red-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900">{t.flood} {t.predictedRisk}</span>
                    <Badge className="bg-red-500">85%</Badge>
                  </div>
                  <p className="text-sm text-gray-600">
                    High probability of flooding in coastal areas. Recommend evacuation.
                  </p>
                </div>
                <div className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border border-orange-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900">{t.highWaves} Risk</span>
                    <Badge className="bg-orange-500">65%</Badge>
                  </div>
                  <p className="text-sm text-gray-600">
                    Elevated wave activity expected in next 6 hours.
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Tabs for Incidents */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <Tabs defaultValue="pending" className="w-full">
              <TabsList className="grid w-full max-w-md grid-cols-3 mb-6">
                <TabsTrigger value="pending" className="flex items-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>{t.pending}</span>
                  <Badge variant="secondary">{pendingIncidents.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="active" className="flex items-center space-x-2">
                  <Activity className="w-4 h-4" />
                  <span>{t.inProgress}</span>
                  <Badge variant="secondary">{activeIncidents.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="map" className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4" />
                  <span>{t.map}</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="pending" className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-gray-900">{t.pending} {t.incidents}</h3>
                  <Button variant="outline" size="sm">
                    <Users className="w-4 h-4 mr-2" />
                    {t.assignTeam}
                  </Button>
                </div>
                <div className="grid gap-4">
                  {pendingIncidents.map((incident) => (
                    <IncidentCard key={incident.id} incident={incident} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="active" className="space-y-4">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {t.inProgress} {t.incidents}
                </h3>
                <div className="grid gap-4">
                  {activeIncidents.map((incident) => (
                    <IncidentCard key={incident.id} incident={incident} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="map">
                <LiveMap />
              </TabsContent>
            </Tabs>
          </Card>

          {/* Anomaly Detection */}
          <Card className="p-6 bg-gradient-to-br from-purple-600 to-pink-600 border-0 text-white">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">{t.anomalyDetection}</h3>
                <p className="text-white/90 mb-4">
                  ⚠️ {t.unusualActivity}
                </p>
                <p className="text-white/90">
                  3x increase in pollution reports near Juhu Beach area. AI analysis suggests potential oil spill.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
      </main>

      {/* AI Copilot Button */}
      <motion.button
        onClick={() => setShowAI(true)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full shadow-2xl flex items-center justify-center text-white hover:scale-110 transition-transform duration-300 z-50"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <MessageSquare className="w-7 h-7" />
      </motion.button>

      {/* AI Copilot */}
      <AICopilot open={showAI} onClose={() => setShowAI(false)} />
    </div>
  );
}
