import { useState } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Waves, Shield, Users, ChevronRight } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card } from '../components/ui/card';
import { LanguageSelector } from '../components/LanguageSelector';

export function LoginPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [selectedRole, setSelectedRole] = useState<'resident' | 'rescue' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (selectedRole === 'resident') {
      navigate('/resident');
    } else if (selectedRole === 'rescue') {
      navigate('/rescue');
    }
  };

  const roles = [
    {
      id: 'resident' as const,
      title: t.resident,
      description: 'Report hazards and send SOS alerts',
      icon: Users,
      gradient: 'from-blue-500 to-cyan-500',
    },
    {
      id: 'rescue' as const,
      title: t.rescueTeam,
      description: 'Manage incidents and coordinate rescue operations',
      icon: Shield,
      gradient: 'from-teal-500 to-emerald-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-teal-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Background Image Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1604580826271-aa59d10b875a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2VhbiUyMHdhdmVzJTIwc3Vuc2V0fGVufDF8fHx8MTc3NjMyNDY4NXww&ixlib=rb-4.1.0&q=80&w=1080)'
          }}
        />
        <motion.div
          className="absolute top-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'linear',
          }}
        />
        <motion.div
          className="absolute bottom-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl"
          animate={{
            x: [0, -100, 0],
            y: [0, -50, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: 'linear',
          }}
        />
      </div>

      {/* Language Selector */}
      <div className="absolute top-6 right-6 z-10">
        <LanguageSelector />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-6xl relative z-10"
      >
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="inline-flex items-center justify-center mb-6"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-teal-400 blur-xl opacity-50" />
              <Waves className="w-20 h-20 text-white relative z-10" />
            </div>
          </motion.div>
          <h1 className="text-5xl font-bold text-white mb-4 tracking-tight">
            {t.appName}
          </h1>
          <p className="text-xl text-blue-100">
            AI-Powered Ocean Hazard Monitoring & Rescue Coordination
          </p>
        </div>

        {!selectedRole ? (
          /* Role Selection */
          <div className="grid md:grid-cols-2 gap-6">
            <h2 className="col-span-full text-2xl font-semibold text-white text-center mb-4">
              {t.selectRole}
            </h2>
            {roles.map((role) => (
              <motion.div
                key={role.id}
                whileHover={{ scale: 1.02, y: -4 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card
                  className="p-8 cursor-pointer bg-white/10 backdrop-blur-xl border border-white/20 hover:bg-white/15 transition-all duration-300 group"
                  onClick={() => setSelectedRole(role.id)}
                >
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${role.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <role.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">{role.title}</h3>
                  <p className="text-blue-100 mb-6">{role.description}</p>
                  <div className="flex items-center text-white font-medium group-hover:translate-x-2 transition-transform duration-300">
                    <span>{t.selectRole}</span>
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          /* Login Form */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md mx-auto"
          >
            <Card className="p-8 bg-white/10 backdrop-blur-xl border border-white/20">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-white mb-2">{t.welcomeBack}</h2>
                <p className="text-blue-100">
                  {selectedRole === 'resident' ? t.resident : t.rescueTeam}
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-white text-sm font-medium mb-2 block">
                    {t.email}
                  </label>
                  <Input
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  />
                </div>

                <div>
                  <label className="text-white text-sm font-medium mb-2 block">
                    {t.password}
                  </label>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                  />
                </div>

                <Button
                  onClick={handleLogin}
                  className="w-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-semibold py-6 text-lg"
                >
                  {t.loginButton}
                </Button>

                <Button
                  variant="ghost"
                  onClick={() => setSelectedRole(null)}
                  className="w-full text-white hover:bg-white/10"
                >
                  {t.back}
                </Button>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Features */}
        <div className="mt-12 grid md:grid-cols-3 gap-6 text-center">
          {[
            { label: 'Real-time SOS Alerts', icon: '🚨' },
            { label: 'AI-Powered Predictions', icon: '🤖' },
            { label: 'Multi-language Support', icon: '🌐' },
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="text-white/80"
            >
              <div className="text-4xl mb-2">{feature.icon}</div>
              <div className="text-sm">{feature.label}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}