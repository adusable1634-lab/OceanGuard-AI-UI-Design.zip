import { useState } from 'react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Languages, Bell, Volume2, Palette, Accessibility } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Language, languageNames } from '../data/translations';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Switch } from '../components/ui/switch';
import { Label } from '../components/ui/label';

export function SettingsPage() {
  const navigate = useNavigate();
  const { t, language, setLanguage } = useLanguage();
  const [notifications, setNotifications] = useState(true);
  const [voiceNav, setVoiceNav] = useState(false);

  const languages: Language[] = ['en', 'hi', 'mr', 'ta', 'bn'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50">
      {/* Header */}
      <div className="bg-white/70 backdrop-blur-xl border-b border-white/20 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate(-1)} className="text-gray-600">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{t.settings}</h1>
              <p className="text-sm text-gray-600">Customize your experience</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Language Settings */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                <Languages className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{t.language}</h3>
                <p className="text-sm text-gray-600">Select your preferred language</p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              {languages.map((lang) => (
                <motion.button
                  key={lang}
                  onClick={() => setLanguage(lang)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`p-4 rounded-xl border-2 transition-all duration-300 text-left ${
                    language === lang
                      ? 'bg-blue-50 border-blue-500 shadow-lg'
                      : 'bg-white border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-gray-900">{languageNames[lang]}</div>
                      <div className="text-sm text-gray-600">
                        {lang === 'en' && 'English'}
                        {lang === 'hi' && 'हिंदी'}
                        {lang === 'mr' && 'मराठी'}
                        {lang === 'ta' && 'தமிழ்'}
                        {lang === 'bn' && 'বাংলা'}
                      </div>
                    </div>
                    {language === lang && (
                      <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center">
                        <svg
                          className="w-4 h-4 text-white"
                          fill="none"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </div>
                </motion.button>
              ))}
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-900">
                💡 Language changes apply to the entire application instantly
              </p>
            </div>
          </Card>

          {/* Notifications */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <Bell className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{t.notifications}</h3>
                <p className="text-sm text-gray-600">Manage alert preferences</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div>
                  <Label htmlFor="notifications" className="font-semibold text-gray-900">
                    {t.notifications}
                  </Label>
                  <p className="text-sm text-gray-600">Receive alerts and updates</p>
                </div>
                <Switch
                  id="notifications"
                  checked={notifications}
                  onCheckedChange={setNotifications}
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div>
                  <Label htmlFor="sos-alerts" className="font-semibold text-gray-900">
                    SOS {t.alerts}
                  </Label>
                  <p className="text-sm text-gray-600">Critical emergency notifications</p>
                </div>
                <Switch id="sos-alerts" defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div>
                  <Label htmlFor="hazard-alerts" className="font-semibold text-gray-900">
                    {t.hazardReports}
                  </Label>
                  <p className="text-sm text-gray-600">Hazard detection notifications</p>
                </div>
                <Switch id="hazard-alerts" defaultChecked />
              </div>

              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div>
                  <Label htmlFor="weather-alerts" className="font-semibold text-gray-900">
                    {t.weatherAlert}
                  </Label>
                  <p className="text-sm text-gray-600">Weather-related alerts</p>
                </div>
                <Switch id="weather-alerts" defaultChecked />
              </div>
            </div>
          </Card>

          {/* Accessibility */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-teal-500 flex items-center justify-center">
                <Accessibility className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{t.accessibility}</h3>
                <p className="text-sm text-gray-600">Accessibility features</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div className="flex items-center space-x-3">
                  <Volume2 className="w-5 h-5 text-gray-600" />
                  <div>
                    <Label htmlFor="voice-nav" className="font-semibold text-gray-900">
                      {t.voiceNavigation}
                    </Label>
                    <p className="text-sm text-gray-600">{t.enableVoice} navigation and input</p>
                  </div>
                </div>
                <Switch id="voice-nav" checked={voiceNav} onCheckedChange={setVoiceNav} />
              </div>

              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div>
                  <Label htmlFor="high-contrast" className="font-semibold text-gray-900">
                    High Contrast Mode
                  </Label>
                  <p className="text-sm text-gray-600">Enhanced visibility for better readability</p>
                </div>
                <Switch id="high-contrast" />
              </div>

              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div>
                  <Label htmlFor="large-text" className="font-semibold text-gray-900">
                    Large Text
                  </Label>
                  <p className="text-sm text-gray-600">Increase text size for easier reading</p>
                </div>
                <Switch id="large-text" />
              </div>
            </div>
          </Card>

          {/* Theme */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
                <Palette className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{t.theme}</h3>
                <p className="text-sm text-gray-600">Customize appearance</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {[
                { name: 'Light', gradient: 'from-white to-gray-100' },
                { name: 'Dark', gradient: 'from-gray-800 to-gray-900' },
                { name: 'Ocean', gradient: 'from-blue-500 to-teal-500' },
              ].map((theme) => (
                <motion.button
                  key={theme.name}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`p-4 rounded-xl border-2 ${
                    theme.name === 'Ocean' ? 'border-blue-500 ring-2 ring-blue-200' : 'border-gray-200'
                  }`}
                >
                  <div className={`w-full h-16 rounded-lg bg-gradient-to-br ${theme.gradient} mb-2`} />
                  <div className="text-sm font-semibold text-gray-900">{theme.name}</div>
                </motion.button>
              ))}
            </div>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-semibold px-8"
            >
              {t.save} {t.settings}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
