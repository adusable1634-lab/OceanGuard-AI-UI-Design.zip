import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Layers, Navigation } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { LiveMap } from '../components/LiveMap';

export function MapPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50">
      {/* Header */}
      <div className="bg-white/70 backdrop-blur-xl border-b border-white/20 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate(-1)} className="text-gray-600">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{t.map}</h1>
              <p className="text-sm text-gray-600">Real-time hazard monitoring</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <Tabs defaultValue="live" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="live">
                  <Navigation className="w-4 h-4 mr-2" />
                  {t.liveLocation}
                </TabsTrigger>
                <TabsTrigger value="layers">
                  <Layers className="w-4 h-4 mr-2" />
                  Map Layers
                </TabsTrigger>
              </TabsList>

              <TabsContent value="live">
                <LiveMap />
              </TabsContent>

              <TabsContent value="layers">
                <div className="space-y-4">
                  <p className="text-gray-600">Select map layers to display:</p>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[
                      { label: t.hazardReports, active: true },
                      { label: t.safeZones, active: true },
                      { label: t.rescueCenters, active: true },
                      { label: 'Weather Overlay', active: false },
                      { label: 'Ocean Conditions', active: false },
                      { label: 'Risk Heatmap', active: false },
                    ].map((layer, index) => (
                      <Card
                        key={index}
                        className={`p-4 cursor-pointer transition-all duration-300 ${
                          layer.active
                            ? 'bg-blue-50 border-blue-300'
                            : 'bg-white border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                              layer.active
                                ? 'bg-blue-600 border-blue-600'
                                : 'border-gray-300'
                            }`}
                          >
                            {layer.active && (
                              <svg
                                className="w-3 h-3 text-white"
                                fill="none"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth="2"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                          <span className="font-medium text-gray-900">{layer.label}</span>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
