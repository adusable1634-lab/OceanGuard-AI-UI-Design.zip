import { useState } from 'react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import {
  ArrowLeft,
  Upload,
  MapPin,
  Mic,
  Image as ImageIcon,
  Video,
  Droplets,
  AlertTriangle,
  Fish,
  Waves as WavesIcon,
  Wind,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';

export function ReportHazardPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [selectedType, setSelectedType] = useState<string>('');
  const [location, setLocation] = useState('Mumbai, Maharashtra');
  const [description, setDescription] = useState('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [aiDetection, setAiDetection] = useState<string | null>(null);

  const hazardTypes = [
    {
      id: 'oilSpill',
      label: t.oilSpill,
      icon: Droplets,
      color: 'from-gray-700 to-gray-900',
      bgColor: 'bg-gray-50',
      borderColor: 'border-gray-300',
    },
    {
      id: 'flood',
      label: t.flood,
      icon: WavesIcon,
      color: 'from-blue-600 to-blue-800',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-300',
    },
    {
      id: 'deadMarineLife',
      label: t.deadMarineLife,
      icon: Fish,
      color: 'from-red-600 to-red-800',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-300',
    },
    {
      id: 'highWaves',
      label: t.highWaves,
      icon: Wind,
      color: 'from-teal-600 to-teal-800',
      bgColor: 'bg-teal-50',
      borderColor: 'border-teal-300',
    },
    {
      id: 'pollution',
      label: t.pollution,
      icon: AlertTriangle,
      color: 'from-orange-600 to-orange-800',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-300',
    },
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        // Simulate AI detection
        setTimeout(() => {
          const detections = [
            `${t.detectedHazard}: Oil Spill (High Risk)`,
            `${t.detectedHazard}: Pollution (Medium Risk)`,
            `${t.detectedHazard}: Dead Marine Life (High Risk)`,
          ];
          setAiDetection(detections[Math.floor(Math.random() * detections.length)]);
        }, 1500);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!selectedType || !description) {
      toast.error(t.error, {
        description: 'Please fill in all required fields',
      });
      return;
    }

    toast.success(t.reportSubmitted, {
      description: 'Rescue teams have been notified',
    });

    setTimeout(() => {
      navigate('/resident');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50">
      {/* Header */}
      <div className="bg-white/70 backdrop-blur-xl border-b border-white/20 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={() => navigate('/resident')}
              className="text-gray-600"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{t.reportHazard}</h1>
              <p className="text-sm text-gray-600">Help keep our oceans safe</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Hazard Type Selection */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <Label className="text-lg font-semibold text-gray-900 mb-4 block">
              {t.hazardType} *
            </Label>
            <div className="grid sm:grid-cols-3 md:grid-cols-5 gap-4">
              {hazardTypes.map((type) => (
                <motion.button
                  key={type.id}
                  onClick={() => setSelectedType(type.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                    selectedType === type.id
                      ? `${type.bgColor} ${type.borderColor} shadow-lg`
                      : 'bg-white border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div
                    className={`w-12 h-12 rounded-lg bg-gradient-to-br ${type.color} flex items-center justify-center mx-auto mb-2`}
                  >
                    <type.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-xs font-medium text-gray-900 text-center">
                    {type.label}
                  </div>
                </motion.button>
              ))}
            </div>
          </Card>

          {/* Location */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <Label className="text-lg font-semibold text-gray-900 mb-4 block">
              {t.location} *
            </Label>
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-blue-600 flex-shrink-0" />
              <Input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder={t.autoDetectLocation}
                className="flex-1"
              />
              <Button variant="outline" className="flex-shrink-0">
                {t.autoDetectLocation}
              </Button>
            </div>
          </Card>

          {/* Media Upload */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <Label className="text-lg font-semibold text-gray-900 mb-4 block">
              {t.uploadPhoto} / {t.uploadVideo}
            </Label>
            
            {uploadedImage ? (
              <div className="relative">
                <img
                  src={uploadedImage}
                  alt="Uploaded hazard"
                  className="w-full h-64 object-cover rounded-lg"
                />
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => {
                    setUploadedImage(null);
                    setAiDetection(null);
                  }}
                  className="absolute top-2 right-2"
                >
                  Remove
                </Button>
                {aiDetection && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-4 p-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg text-white"
                  >
                    <div className="flex items-center space-x-2 mb-2">
                      <AlertTriangle className="w-5 h-5" />
                      <span className="font-semibold">AI Detection Result</span>
                    </div>
                    <p>{aiDetection}</p>
                  </motion.div>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-4">
                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <div className="p-6 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 text-center">
                    <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <div className="text-sm font-medium text-gray-700">{t.uploadPhoto}</div>
                  </div>
                </label>

                <label className="cursor-pointer">
                  <input type="file" accept="video/*" className="hidden" />
                  <div className="p-6 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 text-center">
                    <Video className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <div className="text-sm font-medium text-gray-700">{t.uploadVideo}</div>
                  </div>
                </label>

                <button className="p-6 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all duration-300">
                  <Mic className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <div className="text-sm font-medium text-gray-700">{t.voiceInput}</div>
                </button>
              </div>
            )}
          </Card>

          {/* Description */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <Label className="text-lg font-semibold text-gray-900 mb-4 block">
              {t.description} *
            </Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what you observed..."
              rows={5}
              className="w-full"
            />
          </Card>

          {/* Submit Button */}
          <div className="flex space-x-4">
            <Button
              variant="outline"
              onClick={() => navigate('/resident')}
              className="flex-1"
            >
              {t.cancel}
            </Button>
            <Button
              onClick={handleSubmit}
              className="flex-1 bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-semibold py-6 text-lg"
            >
              <Upload className="w-5 h-5 mr-2" />
              {t.submitReport}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
