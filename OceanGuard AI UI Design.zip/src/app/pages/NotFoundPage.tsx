import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { Home, Waves } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';

export function NotFoundPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-teal-900 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="mb-8"
        >
          <Waves className="w-32 h-32 text-blue-300 mx-auto" />
        </motion.div>
        
        <h1 className="text-9xl font-bold text-white mb-4">404</h1>
        <h2 className="text-3xl font-bold text-blue-100 mb-4">Page Not Found</h2>
        <p className="text-blue-200 mb-8 max-w-md mx-auto">
          The page you're looking for has drifted away like a message in a bottle.
        </p>
        
        <Button
          onClick={() => navigate('/')}
          className="bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white font-semibold px-8 py-6 text-lg"
        >
          <Home className="w-5 h-5 mr-2" />
          {t.home}
        </Button>
      </motion.div>
    </div>
  );
}
