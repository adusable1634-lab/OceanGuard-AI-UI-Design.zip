import { motion } from 'motion/react';
import { useNavigate } from 'react-router';
import { ArrowLeft, TrendingUp, MessageCircle, AlertTriangle, BarChart3 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  mockSocialMediaPosts,
  mockPredictionData,
  mockSentimentData,
  mockMentionsOverTime,
} from '../data/mockData';

export function AnalyticsPage() {
  const navigate = useNavigate();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      {/* Header */}
      <div className="bg-white/70 backdrop-blur-xl border-b border-white/20 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate(-1)} className="text-gray-600">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{t.socialMediaAnalytics}</h1>
              <p className="text-sm text-gray-600">AI-powered disaster detection from social media</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Stats */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Total Mentions', value: '5,417', icon: MessageCircle, color: 'blue' },
              { label: 'High Risk Posts', value: '156', icon: AlertTriangle, color: 'red' },
              { label: 'Trending Topics', value: '23', icon: TrendingUp, color: 'green' },
              { label: 'AI Predictions', value: '89%', icon: BarChart3, color: 'purple' },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                      <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                    </div>
                    <div className={`w-12 h-12 rounded-xl bg-${stat.color}-100 flex items-center justify-center`}>
                      <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Prediction Chart */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <h3 className="text-xl font-bold text-gray-900 mb-6">{t.predictedRisk} vs {t.actualRisk}</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={mockPredictionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke="#8b5cf6"
                  strokeWidth={3}
                  dot={{ fill: '#8b5cf6', r: 5 }}
                  name="Predicted Risk"
                />
                <Line
                  type="monotone"
                  dataKey="actual"
                  stroke="#06b6d4"
                  strokeWidth={3}
                  dot={{ fill: '#06b6d4', r: 5 }}
                  name="Actual Risk"
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Sentiment Analysis & Mentions */}
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-6">{t.sentimentAnalysis}</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={mockSentimentData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {mockSentimentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-6">{t.mentionsOverTime}</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={mockMentionsOverTime}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="time" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.9)',
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="mentions" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Trending Posts */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <h3 className="text-xl font-bold text-gray-900 mb-6">{t.trendingPosts}</h3>
            <div className="space-y-4">
              {mockSocialMediaPosts.slice(0, 5).map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 rounded-lg border-2 ${
                    post.sentiment === 'negative'
                      ? 'bg-red-50 border-red-200'
                      : post.sentiment === 'neutral'
                      ? 'bg-yellow-50 border-yellow-200'
                      : 'bg-green-50 border-green-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <Badge variant="outline" className="capitalize">
                          {post.platform}
                        </Badge>
                        <Badge
                          className={
                            post.riskScore >= 80
                              ? 'bg-red-500'
                              : post.riskScore >= 60
                              ? 'bg-orange-500'
                              : 'bg-yellow-500'
                          }
                        >
                          Risk: {post.riskScore}%
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {new Date(post.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-gray-900 mb-2">{post.content}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>📍 {post.location}</span>
                        <span>💬 {post.mentions} mentions</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>

          {/* AI Insights */}
          <Card className="p-6 bg-gradient-to-br from-purple-600 to-pink-600 border-0 text-white">
            <h3 className="text-xl font-bold mb-4">🤖 AI Insights</h3>
            <div className="space-y-3">
              <div className="p-4 bg-white/10 backdrop-blur-sm rounded-lg">
                <p className="font-semibold mb-1">High Flood Probability</p>
                <p className="text-white/90 text-sm">
                  {t.highProbabilityFlood}. Social media activity shows 3x increase in flood-related posts.
                </p>
              </div>
              <div className="p-4 bg-white/10 backdrop-blur-sm rounded-lg">
                <p className="font-semibold mb-1">Coastal Area Alert</p>
                <p className="text-white/90 text-sm">
                  Unusual spike in mentions around Juhu Beach area. Recommend immediate investigation.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
