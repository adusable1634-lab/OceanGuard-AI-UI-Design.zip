import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router';
import {
  Waves,
  AlertCircle,
  MapPin,
  Bell,
  Settings,
  LogOut,
  MessageSquare,
  AlertTriangle,
  Menu,
  X,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { LanguageSelector } from '../components/LanguageSelector';
import { SOSButton } from '../components/SOSButton';
import { AlertsList } from '../components/AlertsList';
import { AICopilot } from '../components/AICopilot';
import { mockAlerts } from '../data/mockData';

export function ResidentDashboard() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [showAI, setShowAI] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const quickActions = [
    {
      icon: AlertTriangle,
      label: t.reportHazard,
      description: 'Report ocean hazards',
      gradient: 'from-orange-500 to-red-500',
      action: () => navigate('/report-hazard'),
    },
    {
      icon: MapPin,
      label: t.map,
      description: 'View hazard map',
      gradient: 'from-green-500 to-teal-500',
      action: () => navigate('/map'),
    },
    {
      icon: Bell,
      label: t.alerts,
      description: `${mockAlerts.length} active alerts`,
      gradient: 'from-blue-500 to-purple-500',
      badge: mockAlerts.length,
    },
    {
      icon: Settings,
      label: t.settings,
      description: 'App preferences',
      gradient: 'from-gray-500 to-gray-600',
      action: () => navigate('/settings'),
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50">
      {/* Header */}
      <header className="bg-white/70 backdrop-blur-xl border-b border-white/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-teal-400 blur-lg opacity-50" />
                <Waves className="w-8 h-8 text-blue-600 relative z-10" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{t.appName}</h1>
                <p className="text-sm text-gray-600">{t.resident}</p>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-4">
              <LanguageSelector />
              <Button
                variant="ghost"
                onClick={() => navigate('/')}
                className="text-gray-600"
              >
                <LogOut className="w-4 h-4 mr-2" />
                {t.logout}
              </Button>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-gray-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          <AnimatePresence>
            {mobileMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="md:hidden mt-4 space-y-2"
              >
                <LanguageSelector />
                <Button
                  variant="ghost"
                  onClick={() => navigate('/')}
                  className="w-full justify-start"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  {t.logout}
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          {/* Welcome Section */}
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              {t.welcome} 👋
            </h2>
            <p className="text-gray-600">Stay safe with real-time ocean monitoring</p>
          </div>

          {/* SOS Section */}
          <Card className="p-8 bg-gradient-to-br from-red-500 to-pink-600 border-0 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS1vcGFjaXR5PSIwLjA1IiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20" />
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-2">{t.emergencyAlert}</h3>
                <p className="text-white/90 mb-4">{t.sosDescription}</p>
              </div>
              <SOSButton />
            </div>
          </Card>

          {/* Quick Actions Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickActions.map((action, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -4 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card
                  className="p-6 cursor-pointer bg-white/70 backdrop-blur-sm border border-white/20 hover:bg-white/90 transition-all duration-300 group relative overflow-hidden"
                  onClick={action.action}
                >
                  <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${action.gradient} opacity-10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500`} />
                  
                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${action.gradient} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                        <action.icon className="w-6 h-6 text-white" />
                      </div>
                      {action.badge !== undefined && (
                        <Badge className="bg-red-500 text-white">{action.badge}</Badge>
                      )}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">{action.label}</h3>
                    <p className="text-sm text-gray-600">{action.description}</p>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Recent Alerts */}
          <Card className="p-6 bg-white/70 backdrop-blur-sm border border-white/20">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-2">
                <Bell className="w-5 h-5 text-blue-600" />
                <h3 className="text-xl font-bold text-gray-900">{t.alerts}</h3>
              </div>
              <Badge variant="outline" className="text-blue-600 border-blue-600">
                {mockAlerts.length} Active
              </Badge>
            </div>
            <AlertsList alerts={mockAlerts.slice(0, 3)} />
          </Card>

          {/* Safety Tips */}
          <Card className="p-6 bg-gradient-to-br from-blue-600 to-teal-600 border-0 text-white">
            <h3 className="text-xl font-bold mb-4">💡 Safety Tips</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>Always check weather alerts before going to the beach</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>Report any unusual ocean activities immediately</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2">•</span>
                <span>Keep emergency contacts readily available</span>
              </li>
            </ul>
          </Card>
        </motion.div>
      </main>

      {/* AI Copilot Button */}
      <motion.button
        onClick={() => setShowAI(true)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full shadow-2xl flex items-center justify-center text-white hover:scale-110 transition-transform duration-300 z-50"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <MessageSquare className="w-7 h-7" />
      </motion.button>

      {/* AI Copilot */}
      <AICopilot open={showAI} onClose={() => setShowAI(false)} />
    </div>
  );
}
