import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface RiskMeterProps {
  level: number; // 0-100
}

export function RiskMeter({ level }: RiskMeterProps) {
  const { t } = useLanguage();

  const getRiskLabel = (level: number) => {
    if (level >= 75) return { label: t.critical, color: '#ef4444' };
    if (level >= 50) return { label: t.high, color: '#f97316' };
    if (level >= 25) return { label: t.medium, color: '#eab308' };
    return { label: t.low, color: '#22c55e' };
  };

  const risk = getRiskLabel(level);

  return (
    <div className="space-y-4">
      {/* Circular Progress */}
      <div className="relative w-48 h-48 mx-auto">
        <svg className="w-full h-full transform -rotate-90">
          {/* Background Circle */}
          <circle
            cx="96"
            cy="96"
            r="80"
            fill="none"
            stroke="#e5e7eb"
            strokeWidth="12"
          />
          {/* Progress Circle */}
          <motion.circle
            cx="96"
            cy="96"
            r="80"
            fill="none"
            stroke={risk.color}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={502.4}
            initial={{ strokeDashoffset: 502.4 }}
            animate={{ strokeDashoffset: 502.4 - (502.4 * level) / 100 }}
            transition={{ duration: 1.5, ease: 'easeInOut' }}
          />
        </svg>
        
        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, type: 'spring' }}
            className="text-5xl font-bold"
            style={{ color: risk.color }}
          >
            {level}
          </motion.div>
          <div className="text-sm text-gray-600 mt-1">Risk Score</div>
        </div>
      </div>

      {/* Risk Level Badge */}
      <div className="text-center">
        <div
          className="inline-block px-6 py-2 rounded-full font-semibold text-white"
          style={{ backgroundColor: risk.color }}
        >
          {risk.label} Risk
        </div>
      </div>

      {/* Risk Breakdown */}
      <div className="space-y-2 pt-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Weather</span>
          <div className="flex items-center space-x-2">
            <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-orange-500"
                initial={{ width: 0 }}
                animate={{ width: '75%' }}
                transition={{ delay: 0.5, duration: 1 }}
              />
            </div>
            <span className="font-semibold text-gray-900">75%</span>
          </div>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Social Media</span>
          <div className="flex items-center space-x-2">
            <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-red-500"
                initial={{ width: 0 }}
                animate={{ width: '85%' }}
                transition={{ delay: 0.6, duration: 1 }}
              />
            </div>
            <span className="font-semibold text-gray-900">85%</span>
          </div>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Ocean Conditions</span>
          <div className="flex items-center space-x-2">
            <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-yellow-500"
                initial={{ width: 0 }}
                animate={{ width: '60%' }}
                transition={{ delay: 0.7, duration: 1 }}
              />
            </div>
            <span className="font-semibold text-gray-900">60%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
