import { motion } from 'motion/react';
import { MapPin, Clock, User, AlertCircle, Droplets, Fish, Wind, AlertTriangle } from 'lucide-react';
import { Incident } from '../data/mockData';
import { useLanguage } from '../context/LanguageContext';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface IncidentCardProps {
  incident: Incident;
}

export function IncidentCard({ incident }: IncidentCardProps) {
  const { t } = useLanguage();

  const getIcon = () => {
    if (incident.type === 'sos') return AlertCircle;
    switch (incident.hazardType) {
      case 'oilSpill':
        return Droplets;
      case 'deadMarineLife':
        return Fish;
      case 'highWaves':
        return Wind;
      case 'pollution':
        return AlertTriangle;
      default:
        return AlertTriangle;
    }
  };

  const getSeverityColor = () => {
    switch (incident.severity) {
      case 'critical':
        return 'bg-red-100 text-red-700 border-red-300';
      case 'high':
        return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low':
        return 'bg-green-100 text-green-700 border-green-300';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getStatusColor = () => {
    switch (incident.status) {
      case 'resolved':
        return 'bg-green-500';
      case 'inProgress':
        return 'bg-blue-500';
      case 'pending':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  const Icon = getIcon();

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 60000);
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff}m ago`;
    const hours = Math.floor(diff / 60);
    return `${hours}h ago`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`p-6 rounded-xl border-2 ${getSeverityColor()} relative overflow-hidden`}
    >
      {incident.type === 'sos' && (
        <motion.div
          className="absolute top-0 right-0 w-2 h-full bg-red-500"
          animate={{ opacity: [1, 0.3, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        />
      )}

      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start space-x-4 flex-1">
          <div className={`w-12 h-12 rounded-lg ${getSeverityColor()} flex items-center justify-center flex-shrink-0`}>
            <Icon className="w-6 h-6" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <h4 className="font-bold text-gray-900">
                {incident.type === 'sos' ? 'SOS Alert' : t[incident.hazardType as keyof typeof t] || incident.hazardType}
              </h4>
              <Badge className={getStatusColor()}>
                {t[incident.status as keyof typeof t]}
              </Badge>
              <Badge variant="outline">
                {t[incident.severity as keyof typeof t]}
              </Badge>
            </div>

            <p className="text-gray-700 mb-3">{incident.description}</p>

            <div className="grid sm:grid-cols-2 gap-2 text-sm">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 flex-shrink-0" />
                <span className="truncate">{incident.location.name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4 flex-shrink-0" />
                <span className="truncate">{incident.reportedBy}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 flex-shrink-0" />
                <span>{formatTime(incident.timestamp)}</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 flex-shrink-0" />
                <span className="text-xs">
                  {incident.location.lat.toFixed(4)}, {incident.location.lng.toFixed(4)}
                </span>
              </div>
            </div>

            {incident.imageUrl && (
              <img
                src={incident.imageUrl}
                alt="Incident"
                className="mt-3 w-full h-32 object-cover rounded-lg"
              />
            )}
          </div>
        </div>

        <div className="flex flex-col gap-2 flex-shrink-0">
          <Select defaultValue={incident.status}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">{t.pending}</SelectItem>
              <SelectItem value="inProgress">{t.inProgress}</SelectItem>
              <SelectItem value="resolved">{t.resolved}</SelectItem>
            </SelectContent>
          </Select>
          <Button size="sm" variant="outline">
            {t.assignTeam}
          </Button>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
            View Details
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
