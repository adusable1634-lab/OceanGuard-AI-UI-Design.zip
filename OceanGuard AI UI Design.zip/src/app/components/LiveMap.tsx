import { motion } from 'motion/react';
import { MapPin, Navigation, Shield, AlertCircle } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Badge } from './ui/badge';
import { mockHazardLocations, mockSafeZones, mockRescueCenters } from '../data/mockData';

export function LiveMap() {
  const { t } = useLanguage();

  return (
    <div className="space-y-4">
      {/* Map Container */}
      <div className="relative w-full h-[500px] bg-gradient-to-br from-blue-100 to-teal-100 rounded-xl overflow-hidden border-2 border-blue-200">
        {/* Simulated Map Background */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')]" />
        </div>

        {/* Mumbai Coastline Representation */}
        <div className="absolute inset-0">
          <svg className="w-full h-full" viewBox="0 0 800 500">
            {/* Coastline */}
            <path
              d="M 0 300 Q 200 250 400 280 T 800 320"
              fill="none"
              stroke="#2563eb"
              strokeWidth="3"
              strokeDasharray="5,5"
              opacity="0.5"
            />
            {/* Water */}
            <path
              d="M 0 300 Q 200 250 400 280 T 800 320 L 800 500 L 0 500 Z"
              fill="#3b82f6"
              opacity="0.1"
            />
          </svg>
        </div>

        {/* Hazard Markers */}
        {mockHazardLocations.map((hazard, index) => (
          <motion.div
            key={hazard.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            className="absolute"
            style={{
              left: `${15 + index * 18}%`,
              top: `${35 + (index % 3) * 15}%`,
            }}
          >
            <motion.div
              animate={hazard.type === 'sos' ? { scale: [1, 1.2, 1] } : {}}
              transition={{ duration: 1.5, repeat: Infinity }}
              className={`w-10 h-10 rounded-full flex items-center justify-center cursor-pointer shadow-lg ${
                hazard.severity === 'critical'
                  ? 'bg-red-500'
                  : hazard.severity === 'high'
                  ? 'bg-orange-500'
                  : 'bg-yellow-500'
              }`}
            >
              <AlertCircle className="w-6 h-6 text-white" />
            </motion.div>
            {hazard.type === 'sos' && (
              <motion.div
                className="absolute inset-0 rounded-full bg-red-500"
                animate={{ scale: [1, 2, 2], opacity: [0.5, 0, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            )}
          </motion.div>
        ))}

        {/* Safe Zones */}
        {mockSafeZones.map((zone, index) => (
          <motion.div
            key={zone.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.5 + index * 0.1 }}
            className="absolute"
            style={{
              left: `${20 + index * 25}%`,
              top: `${15 + index * 10}%`,
            }}
          >
            <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center cursor-pointer shadow-lg">
              <Shield className="w-5 h-5 text-white" />
            </div>
          </motion.div>
        ))}

        {/* Rescue Centers */}
        {mockRescueCenters.map((center, index) => (
          <motion.div
            key={center.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.8 + index * 0.1 }}
            className="absolute"
            style={{
              left: `${25 + index * 20}%`,
              top: `${60 + index * 8}%`,
            }}
          >
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center cursor-pointer shadow-lg">
              <Navigation className="w-5 h-5 text-white" />
            </div>
          </motion.div>
        ))}

        {/* Map Controls */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          <button className="w-10 h-10 bg-white rounded-lg shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors">
            +
          </button>
          <button className="w-10 h-10 bg-white rounded-lg shadow-lg flex items-center justify-center hover:bg-gray-50 transition-colors">
            -
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-gray-200">
          <div className="flex space-x-1">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-orange-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
          </div>
          <div>
            <div className="font-semibold text-sm text-gray-900">{t.hazardReports}</div>
            <div className="text-xs text-gray-600">Critical / High / Medium</div>
          </div>
        </div>

        <div className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-gray-200">
          <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="font-semibold text-sm text-gray-900">{t.safeZones}</div>
            <div className="text-xs text-gray-600">{mockSafeZones.length} zones</div>
          </div>
        </div>

        <div className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-gray-200">
          <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center">
            <Navigation className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="font-semibold text-sm text-gray-900">{t.rescueCenters}</div>
            <div className="text-xs text-gray-600">{mockRescueCenters.length} centers</div>
          </div>
        </div>
      </div>

      {/* Live Updates */}
      <div className="p-4 bg-gradient-to-r from-blue-50 to-teal-50 rounded-lg border border-blue-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <motion.div
              className="w-2 h-2 rounded-full bg-green-500"
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <span className="text-sm font-semibold text-gray-900">Live Updates Active</span>
          </div>
          <Badge variant="outline">Last updated: Just now</Badge>
        </div>
      </div>
    </div>
  );
}
