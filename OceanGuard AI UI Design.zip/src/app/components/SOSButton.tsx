import { useState } from 'react';
import { motion } from 'motion/react';
import { AlertCircle, MapPin, Phone } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { toast } from 'sonner';

export function SOSButton() {
  const { t } = useLanguage();
  const [showConfirm, setShowConfirm] = useState(false);
  const [sending, setSending] = useState(false);

  const handleSOS = () => {
    setSending(true);
    // Simulate sending SOS
    setTimeout(() => {
      setSending(false);
      setShowConfirm(false);
      toast.success(t.success, {
        description: 'SOS alert sent to rescue teams with your location',
      });
    }, 2000);
  };

  return (
    <>
      <motion.button
        onClick={() => setShowConfirm(true)}
        className="relative w-48 h-48 rounded-full bg-white shadow-2xl flex flex-col items-center justify-center group"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {/* Pulsing Ring */}
        <motion.div
          className="absolute inset-0 rounded-full bg-red-500"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 0, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        
        {/* Inner Circle */}
        <div className="relative z-10">
          <AlertCircle className="w-20 h-20 text-red-600 mb-2" />
          <div className="text-2xl font-bold text-red-600">SOS</div>
          <div className="text-xs text-gray-600 mt-1">{t.sendSOSAlert}</div>
        </div>
      </motion.button>

      <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
        <AlertDialogContent className="bg-white/95 backdrop-blur-xl border border-white/20">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center space-x-2 text-red-600">
              <AlertCircle className="w-6 h-6" />
              <span>{t.emergencyAlert}</span>
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-4">
              <p>{t.sosConfirmation}</p>
              
              <div className="bg-blue-50 p-4 rounded-lg space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span className="text-gray-700">Location: Mumbai, Maharashtra</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Phone className="w-4 h-4 text-blue-600" />
                  <span className="text-gray-700">Emergency Services: Active</span>
                </div>
              </div>

              <p className="text-sm text-gray-600">{t.sosDescription}</p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={sending}>{t.cancel}</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleSOS}
              disabled={sending}
              className="bg-red-600 hover:bg-red-700"
            >
              {sending ? t.loading : t.sendSOSAlert}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
