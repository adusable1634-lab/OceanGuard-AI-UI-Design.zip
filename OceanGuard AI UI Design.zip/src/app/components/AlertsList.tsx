import { motion } from 'motion/react';
import { AlertTriangle, Droplets, Cloud, Navigation } from 'lucide-react';
import { Alert } from '../data/mockData';
import { Badge } from './ui/badge';

interface AlertsListProps {
  alerts: Alert[];
}

export function AlertsList({ alerts }: AlertsListProps) {
  const getIcon = (type: Alert['type']) => {
    switch (type) {
      case 'highTide':
        return Droplets;
      case 'pollution':
        return AlertTriangle;
      case 'weather':
        return Cloud;
      case 'evacuation':
        return Navigation;
      default:
        return AlertTriangle;
    }
  };

  const getSeverityColor = (severity: Alert['severity']) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'medium':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'low':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 60000);
    if (diff < 1) return 'Just now';
    if (diff < 60) return `${diff}m ago`;
    const hours = Math.floor(diff / 60);
    return `${hours}h ago`;
  };

  return (
    <div className="space-y-3">
      {alerts.map((alert, index) => {
        const Icon = getIcon(alert.type);
        return (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-4 rounded-lg border ${getSeverityColor(alert.severity)} flex items-start space-x-3`}
          >
            <Icon className="w-5 h-5 mt-0.5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <p className="font-medium">{alert.message}</p>
                <Badge variant="outline" className="text-xs flex-shrink-0">
                  {formatTime(alert.timestamp)}
                </Badge>
              </div>
              {alert.location && (
                <p className="text-sm opacity-75 mt-1">{alert.location}</p>
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
