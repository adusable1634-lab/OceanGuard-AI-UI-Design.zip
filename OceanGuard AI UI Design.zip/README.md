# 🌊 OceanGuard AI

<div align="center">
  <h3>AI-Powered Ocean Hazard Reporting & Real-Time Rescue Coordination Platform</h3>
  <p>A comprehensive disaster management system with role-based dashboards, multi-language support, and advanced AI analytics</p>
</div>

---

## ✨ Features

### 🎯 Core Functionality

- **Role-Based Access Control**
  - Resident Dashboard: SOS alerts, hazard reporting, personal safety tools
  - Rescue Team Dashboard: Incident management, resource coordination, team dispatch
  
- **Real-Time Emergency Response**
  - One-tap SOS button with location sharing
  - Live incident tracking on interactive maps
  - Automated rescue team notifications
  - Priority-based incident queue

- **AI-Powered Features**
  - 🤖 AI Copilot for intelligent assistance
  - 📊 Hazard prediction & risk analysis
  - 🖼️ Image-based hazard detection
  - 📱 Social media analytics for disaster detection
  - 📈 Predictive analytics dashboard

### 🌍 Multi-Language Support

Full UI translation support for:
- 🇬🇧 English
- 🇮🇳 Hindi (हिंदी)
- 🇮🇳 Marathi (मराठी)
- 🇮🇳 Tamil (தமிழ்)
- 🇮🇳 Bengali (বাংলা)

Language switching is instant and affects the entire application interface.

### 🎨 Design System

- **Ocean-Inspired Color Palette**
  - Deep blue (#0A1E3D) and teal (#00B4D8) primary colors
  - Gradient overlays and glassmorphism effects
  - Clean, modern Google-level UI quality

- **Advanced UI/UX**
  - Smooth animations and transitions
  - Responsive design for all screen sizes
  - Interactive data visualizations with Recharts
  - Material-UI components integration

### 📍 Interactive Mapping

- Real-time incident markers
- Heat maps for hazard-prone areas
- GPS-based location tracking
- Route optimization for rescue teams

### 📊 Analytics & Insights

- Incident trends and statistics
- Response time analytics
- Resource utilization reports
- Social media sentiment analysis
- Predictive risk modeling

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ 
- pnpm (recommended) or npm

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/oceanguard-ai.git
   cd oceanguard-ai
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   # or
   npm install
   ```

3. **Start the development server**
   ```bash
   pnpm dev
   # or
   npm run dev
   ```

4. **Build for production**
   ```bash
   pnpm build
   # or
   npm run build
   ```

---

## 📁 Project Structure

```
oceanguard-ai/
├── src/
│   ├── app/
│   │   ├── components/       # Reusable UI components
│   │   │   ├── ui/          # Base UI component library
│   │   │   ├── AICopilot.tsx
│   │   │   ├── AlertsList.tsx
│   │   │   ├── IncidentCard.tsx
│   │   │   ├── LanguageSelector.tsx
│   │   │   ├── LiveMap.tsx
│   │   │   ├── RiskMeter.tsx
│   │   │   └── SOSButton.tsx
│   │   ├── context/          # React Context providers
│   │   │   └── LanguageContext.tsx
│   │   ├── data/             # Mock data & translations
│   │   │   ├── mockData.ts
│   │   │   └── translations.ts
│   │   ├── pages/            # Application pages
│   │   │   ├── LoginPage.tsx
│   │   │   ├── ResidentDashboard.tsx
│   │   │   ├── RescueDashboard.tsx
│   │   │   ├── ReportHazardPage.tsx
│   │   │   ├── MapPage.tsx
│   │   │   ├── AnalyticsPage.tsx
│   │   │   ├── SettingsPage.tsx
│   │   │   └── NotFoundPage.tsx
│   │   ├── App.tsx           # Main app component
│   │   └── routes.tsx        # React Router configuration
│   └── styles/
│       ├── index.css         # Global styles
│       ├── tailwind.css      # Tailwind imports
│       ├── theme.css         # Custom CSS variables
│       ├── animations.css    # Animation utilities
│       └── fonts.css         # Font imports
├── .gitignore
├── package.json
├── vite.config.ts
├── postcss.config.mjs
└── README.md
```

---

## 🛠️ Tech Stack

### Frontend Framework
- **React 18.3** - Modern UI library
- **TypeScript** - Type-safe development
- **Vite** - Next-generation build tool

### Routing & State
- **React Router 7** - Client-side routing
- **React Context API** - Global state management

### UI & Styling
- **Tailwind CSS 4** - Utility-first CSS framework
- **Radix UI** - Accessible component primitives
- **Material-UI** - Google's Material Design system
- **Lucide React** - Beautiful icon library
- **Motion (Framer Motion)** - Advanced animations

### Data Visualization
- **Recharts** - Composable charting library
- **Canvas Confetti** - Celebration effects

### Form & Validation
- **React Hook Form** - Performant form handling

### Additional Libraries
- **date-fns** - Date manipulation
- **react-dnd** - Drag and drop interactions
- **sonner** - Toast notifications
- **clsx & tailwind-merge** - Conditional styling

---

## 🎮 Usage Guide

### For Residents

1. **Login** - Select "Resident" role
2. **Dashboard** - View active alerts and safety status
3. **SOS Alert** - Tap the emergency button to send your location
4. **Report Hazard** - Submit reports with photos and descriptions
5. **Track Help** - Monitor rescue team response in real-time

### For Rescue Teams

1. **Login** - Select "Rescue Team" role
2. **Control Panel** - View all active incidents
3. **Manage Incidents** - Accept, update status, and resolve cases
4. **Coordinate** - Assign teams and optimize routes
5. **Analytics** - Review performance metrics and trends

### Language Switching

- Click the language selector in the top navigation
- Choose from 5 supported languages
- UI updates instantly without page reload

---

## 🔐 Security & Privacy

- **No Real Data Storage** - This is a demo application with mock data
- **Client-Side Only** - All data is stored locally in browser
- **No Backend Required** - Fully functional frontend demo
- **API Placeholders** - Includes structure for backend integration

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- Built with [Figma Make](https://www.figma.com)
- Icons by [Lucide](https://lucide.dev)
- UI components by [Radix UI](https://www.radix-ui.com) and [Material-UI](https://mui.com)
- Charts by [Recharts](https://recharts.org)

---

## 📧 Contact

For questions or feedback, please open an issue on GitHub.

---

<div align="center">
  <p>Made with ❤️ for ocean safety and disaster management</p>
  <p>🌊 Stay Safe, Stay Connected 🌊</p>
</div>
