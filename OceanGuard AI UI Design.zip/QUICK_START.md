# ⚡ Quick Start Guide

Get OceanGuard AI running in less than 5 minutes!

---

## 🎯 Prerequisites

- **Node.js** 18 or higher ([Download](https://nodejs.org/))
- **pnpm** (recommended) or npm

Check your versions:
```bash
node --version  # Should be v18.0.0 or higher
pnpm --version  # Should be 8.0.0 or higher
```

---

## 🚀 Installation (3 Steps)

### 1️⃣ Clone & Navigate

```bash
git clone https://github.com/yourusername/oceanguard-ai.git
cd oceanguard-ai
```

### 2️⃣ Install Dependencies

```bash
pnpm install
```

*Don't have pnpm? Install it:*
```bash
npm install -g pnpm
```

*Or use npm:*
```bash
npm install
```

### 3️⃣ Start Development Server

```bash
pnpm dev
```

Visit **http://localhost:5173** 🎉

---

## 🎮 First Time Using the App

### Login Screen

1. **Select Your Role:**
   - 🏠 **Resident** - For citizens to report hazards and send SOS
   - 🚁 **Rescue Team** - For emergency responders

2. **Enter Any Name** (this is a demo, no real authentication)

3. Click **"Continue"**

---

## 👤 Resident Dashboard Tour

### Main Features:

1. **🆘 SOS Button** (Top Center)
   - Click to send emergency alert
   - Location is automatically captured
   - Rescue teams are notified

2. **⚠️ Report Hazard** (Navigation)
   - Submit reports with photos
   - Add description and location
   - AI analyzes the report

3. **🗺️ Live Map** (Navigation)
   - View active incidents
   - See nearby hazards
   - Track rescue teams

4. **📊 Analytics** (Navigation)
   - View trends and statistics
   - Social media insights
   - Risk predictions

5. **⚙️ Settings** (Navigation)
   - Change language
   - Notification preferences
   - Profile settings

---

## 🚁 Rescue Team Dashboard Tour

### Main Features:

1. **📋 Active Incidents** (Main View)
   - See all emergency alerts
   - Priority-sorted queue
   - Real-time updates

2. **✅ Manage Incidents**
   - Accept incidents
   - Update status
   - Mark as resolved

3. **👥 Team Coordination**
   - Assign team members
   - View available resources
   - Optimize routes

4. **📈 Analytics Dashboard**
   - Response time metrics
   - Team performance
   - Resource utilization

---

## 🌍 Language Switching

**Change Language Anywhere:**

1. Click the **language selector** (top-right navigation)
2. Choose from:
   - 🇬🇧 English
   - 🇮🇳 हिंदी (Hindi)
   - 🇮🇳 मराठी (Marathi)
   - 🇮🇳 தமிழ் (Tamil)
   - 🇮🇳 বাংলা (Bengali)

3. Entire UI updates instantly!

---

## 🧪 Test Scenarios

### Scenario 1: Send an SOS Alert

1. Login as **Resident**
2. Click the big **SOS button**
3. Confirm your location
4. Alert is sent!

### Scenario 2: Report a Hazard

1. Go to **"Report Hazard"**
2. Choose hazard type (flood, oil spill, etc.)
3. Upload a photo (optional)
4. Add description
5. Submit report

### Scenario 3: Manage as Rescue Team

1. Logout and login as **Rescue Team**
2. See all active incidents
3. Click **"Accept"** on an incident
4. Update status to "In Progress"
5. Mark as **"Resolved"** when done

---

## 🎨 Design Features to Notice

✨ **Glassmorphism Effects** - Translucent cards with blur
🌊 **Ocean Theme** - Deep blue and teal colors
🎭 **Smooth Animations** - Hover effects and transitions
📱 **Responsive Design** - Works on all screen sizes
🤖 **AI Copilot** - Click the floating bot icon

---

## 📁 Project Structure Overview

```
oceanguard-ai/
├── src/app/
│   ├── components/          # Reusable UI components
│   │   ├── SOSButton.tsx   # Emergency button
│   │   ├── LiveMap.tsx     # Interactive map
│   │   └── AICopilot.tsx   # AI assistant
│   ├── pages/               # Main pages
│   │   ├── LoginPage.tsx
│   │   ├── ResidentDashboard.tsx
│   │   └── RescueDashboard.tsx
│   ├── data/
│   │   ├── mockData.ts     # Sample data
│   │   └── translations.ts # All languages
│   └── context/
│       └── LanguageContext.tsx
└── src/styles/              # Global styles
```

---

## 🔧 Useful Commands

```bash
# Development
pnpm dev          # Start dev server
pnpm build        # Build for production
pnpm preview      # Preview production build

# Cleanup
rm -rf node_modules pnpm-lock.yaml
pnpm install      # Fresh install
```

---

## 🐛 Common Issues

### Port 5173 already in use?
```bash
# Kill the process or use a different port
pnpm dev --port 3000
```

### Dependencies not installing?
```bash
# Clear cache and reinstall
pnpm store prune
pnpm install
```

### Build errors?
```bash
# Check Node version
node --version  # Must be 18+

# Try fresh install
rm -rf node_modules
pnpm install
```

---

## 🎓 Next Steps

1. ✅ **Explore all dashboards**
2. ✅ **Test language switching**
3. ✅ **Try the AI Copilot**
4. ✅ **Check the analytics page**
5. ✅ **Customize the theme** (see `src/styles/theme.css`)

---

## 📚 Learn More

- [Full README](README.md) - Complete documentation
- [Deployment Guide](DEPLOYMENT.md) - How to deploy
- [Contributing](CONTRIBUTING.md) - How to contribute

---

## 🆘 Need Help?

- 📖 Check the [full documentation](README.md)
- 🐛 [Report bugs](https://github.com/yourusername/oceanguard-ai/issues)
- 💬 [Ask questions](https://github.com/yourusername/oceanguard-ai/discussions)

---

## 🎉 You're All Set!

Enjoy exploring OceanGuard AI. The app is fully functional with mock data, so feel free to click around and test all features!

**Stay Safe, Stay Connected! 🌊**
