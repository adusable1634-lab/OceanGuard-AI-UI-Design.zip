# 📸 Screenshot Guide for GitHub

Make your GitHub repository stand out with great screenshots! This guide shows you what to capture and how to present it.

---

## 🎯 Recommended Screenshots

### 1. Hero Screenshot (Main Banner)
**Purpose:** First impression of your app  
**What to capture:** Login page or main dashboard  
**Size:** 1280 x 720 px (16:9 ratio)  
**File:** `screenshots/hero.png`

**How to take it:**
1. Open app at full screen (1920x1080 minimum)
2. Use Resident Dashboard with some active alerts
3. Use browser screenshot or OS screenshot tool
4. Crop to remove browser chrome (optional)

---

### 2. Role Selection
**What to capture:** Login page showing both role options  
**File:** `screenshots/login.png`

---

### 3. Resident Dashboard
**What to capture:** Full resident view with:
- SOS button visible
- Active alerts list
- Navigation menu
- Language selector

**File:** `screenshots/resident-dashboard.png`

---

### 4. SOS Alert in Action
**What to capture:** SOS button activated state  
**File:** `screenshots/sos-alert.png`

---

### 5. Hazard Reporting Form
**What to capture:** Report hazard page with form filled  
**File:** `screenshots/report-hazard.png`

---

### 6. Rescue Team Dashboard
**What to capture:** Rescue dashboard with incident cards  
**File:** `screenshots/rescue-dashboard.png`

---

### 7. Interactive Map
**What to capture:** Map page with multiple incident markers  
**File:** `screenshots/map-view.png`

---

### 8. Analytics Dashboard
**What to capture:** Analytics page with charts and graphs  
**File:** `screenshots/analytics.png`

---

### 9. Language Switching
**What to capture:** Side-by-side comparison of different languages  
**File:** `screenshots/multi-language.png`

**Create a collage:**
- English version (left)
- Hindi version (middle)  
- Tamil version (right)

---

### 10. Mobile Responsive View
**What to capture:** App on mobile screen size  
**File:** `screenshots/mobile-view.png`

**How to get it:**
1. Open browser DevTools (F12)
2. Toggle device toolbar (Cmd/Ctrl + Shift + M)
3. Select iPhone or Android device
4. Take screenshot

---

## 📁 Folder Structure

Create a `screenshots` folder in your project:

```
screenshots/
├── hero.png                 # Main banner (1280x720)
├── login.png                # Role selection
├── resident-dashboard.png   # Resident view
├── sos-alert.png           # SOS activated
├── report-hazard.png       # Hazard form
├── rescue-dashboard.png    # Rescue view
├── map-view.png            # Interactive map
├── analytics.png           # Charts/graphs
├── multi-language.png      # Language demo
└── mobile-view.png         # Mobile responsive
```

**Add to .gitignore:**
```
# Screenshots folder (optional - remove if you want to commit them)
# screenshots/
```

**Or keep them:** If you want screenshots in the repo (recommended for README), don't add to .gitignore.

---

## 🎨 Screenshot Tips

### For Best Results:

1. **Clean Browser**
   - Use incognito/private mode (no extensions)
   - Hide bookmarks bar
   - Use Chrome or Firefox
   - Full screen mode (F11)

2. **Consistent Window Size**
   - Use same window size for all screenshots
   - Recommended: 1920 x 1080 px
   - Or use browser DevTools device mode

3. **Good Data**
   - Use meaningful sample data
   - Show variety (different hazard types, statuses)
   - Avoid lorem ipsum text
   - Use realistic names and locations

4. **Timing**
   - Capture UI in its best state
   - Show hover effects or active states
   - Include some data in charts
   - Demonstrate key features

5. **Lighting/Theme**
   - Stick to one theme (light or dark)
   - Good contrast
   - No glare or reflections

---

## 🛠️ Screenshot Tools

### Built-in Tools:

**Mac:**
- Cmd + Shift + 4 (region selection)
- Cmd + Shift + 3 (full screen)

**Windows:**
- Snipping Tool
- Win + Shift + S (Snip & Sketch)
- Print Screen key

**Linux:**
- Screenshot app
- Shift + Print Screen

### Browser Tools:

**Chrome DevTools:**
1. F12 → Open DevTools
2. Cmd/Ctrl + Shift + P → Command palette
3. Type "screenshot"
4. Choose "Capture full size screenshot"

### Recommended Apps:

- **Lightshot** (Cross-platform, free)
- **Greenshot** (Windows, free)
- **Skitch** (Mac, free)
- **ShareX** (Windows, open source)
- **Flameshot** (Linux, open source)

---

## 🎞️ Creating Animations/GIFs

For demo GIFs showing interactions:

### Tools:
- **LICEcap** (Mac/Windows, free)
- **ScreenToGif** (Windows, free)
- **Kap** (Mac, free)
- **Peek** (Linux, free)

### What to Record:
1. **SOS Button Click** (2-3 seconds)
2. **Language Switching** (3-4 seconds)
3. **Hazard Reporting Flow** (5-8 seconds)
4. **Map Interaction** (3-5 seconds)

### GIF Settings:
- Frame rate: 15-20 fps
- Size: Max 800px width
- Keep under 5 MB
- Optimize with tools like [ezgif.com](https://ezgif.com/optimize)

**Save GIFs in:**
```
screenshots/demos/
├── sos-demo.gif
├── language-switch.gif
├── report-flow.gif
└── map-interaction.gif
```

---

## 📝 Adding Screenshots to README

### Hero Image

```markdown
<div align="center">
  <img src="screenshots/hero.png" alt="OceanGuard AI Dashboard" width="800">
</div>
```

### Feature Showcase

```markdown
## 📸 Screenshots

### Resident Dashboard
![Resident Dashboard](screenshots/resident-dashboard.png)

### Rescue Team Control Panel
![Rescue Dashboard](screenshots/rescue-dashboard.png)

### Interactive Maps
![Map View](screenshots/map-view.png)

### Analytics & Insights
![Analytics](screenshots/analytics.png)
```

### Side-by-Side Comparison

```markdown
## 🌍 Multi-Language Support

<p align="center">
  <img src="screenshots/lang-english.png" width="30%" />
  <img src="screenshots/lang-hindi.png" width="30%" />
  <img src="screenshots/lang-tamil.png" width="30%" />
</p>
```

### GIF Demo

```markdown
## 🎬 Demo

### SOS Alert in Action
![SOS Demo](screenshots/demos/sos-demo.gif)
```

---

## 🎨 Creating a Feature Grid

```markdown
## ✨ Key Features

<table>
  <tr>
    <td width="50%">
      <h3>🆘 Emergency Alerts</h3>
      <img src="screenshots/sos-alert.png" alt="SOS Alert" />
    </td>
    <td width="50%">
      <h3>📊 Analytics Dashboard</h3>
      <img src="screenshots/analytics.png" alt="Analytics" />
    </td>
  </tr>
  <tr>
    <td width="50%">
      <h3>🗺️ Live Mapping</h3>
      <img src="screenshots/map-view.png" alt="Map" />
    </td>
    <td width="50%">
      <h3>🌍 Multi-Language</h3>
      <img src="screenshots/multi-language.png" alt="Languages" />
    </td>
  </tr>
</table>
```

---

## 🔧 Optimizing Images

Before uploading to GitHub:

### Compress Images:
- Use [TinyPNG](https://tinypng.com/)
- Or [ImageOptim](https://imageoptim.com/) (Mac)
- Or [Squoosh](https://squoosh.app/) (Web)

### Target Sizes:
- Hero: ~200-300 KB
- Feature screenshots: ~100-150 KB each
- GIFs: Under 5 MB

### Format Recommendations:
- **PNG**: For UI screenshots (better quality)
- **JPG**: For photos or complex images
- **GIF**: For short animations
- **WebP**: For modern browsers (smaller size)

---

## 📊 Social Preview Image

Create a special image for GitHub's social preview (when shared on Twitter, etc.):

### Dimensions:
**1280 x 640 px** (2:1 ratio)

### What to Include:
- App logo/name
- Tagline: "AI-Powered Ocean Hazard Reporting"
- Hero screenshot or key feature
- Ocean-themed background

### Tools to Create:
- Canva (free templates)
- Figma
- Photoshop/GIMP

### Upload:
1. Go to GitHub repo Settings
2. Scroll to "Social preview"
3. Upload image

---

## ✅ Screenshot Checklist

Before publishing:

- [ ] All screenshots taken at consistent size
- [ ] Images compressed for web
- [ ] Screenshots show actual features
- [ ] UI is clean (no errors/warnings)
- [ ] Filenames are descriptive
- [ ] Images are referenced in README
- [ ] Social preview image uploaded
- [ ] Mobile screenshots included
- [ ] At least one GIF demo
- [ ] Folder structure organized

---

## 🎯 Quick Screenshot Workflow

1. **Prepare the App**
   ```bash
   pnpm dev
   # Open http://localhost:5173
   ```

2. **Set Up Browser**
   - Incognito mode
   - 1920x1080 window
   - Hide bookmarks

3. **Capture Each View**
   - Login page
   - Both dashboards
   - All major features
   - Mobile view

4. **Optimize**
   - Compress images
   - Rename files clearly
   - Move to screenshots/ folder

5. **Add to README**
   - Insert markdown image tags
   - Test that images display
   - Push to GitHub

---

## 📱 Mobile Screenshot Tips

### Using Browser DevTools:

1. Press F12
2. Click device toggle (phone icon)
3. Select device (iPhone 12 Pro, etc.)
4. Capture with Cmd/Ctrl + Shift + P → "screenshot"

### Recommended Devices to Show:
- iPhone 12 Pro (390 x 844)
- iPad (768 x 1024)
- Pixel 5 (393 x 851)

---

## 🎨 Creating Mockups

Use mockup generators to showcase your app:

### Free Tools:
- [Screely](https://www.screely.com/) - Add browser frame
- [MockUPhone](https://mockuphone.com/) - Device mockups
- [Shots](https://shots.so/) - Beautiful mockups

### Example:
Upload your screenshot → Get professional mockup with device frame

---

## 💡 Pro Tips

1. **Take More Than You Need**
   - Capture 2-3 versions of each view
   - Choose the best one later

2. **Document Features Visually**
   - One screenshot per major feature
   - Show before/after states

3. **Update Regularly**
   - Retake screenshots when UI changes
   - Keep README images current

4. **Consider Video**
   - Record a 30-second demo
   - Upload to YouTube
   - Embed in README

---

## 🎬 Video Demo (Optional)

### Quick Demo Script (30 seconds):

```
0:00 - Show login page
0:03 - Select "Resident" role
0:05 - Dashboard overview
0:08 - Click SOS button
0:11 - Show hazard reporting
0:15 - Switch to Rescue dashboard
0:20 - View map with incidents
0:25 - Switch language
0:28 - Show analytics
0:30 - End with logo
```

### Tools:
- **Screen Recording:** OBS Studio, QuickTime, Windows Game Bar
- **Editing:** iMovie, Windows Photos, DaVinci Resolve (free)
- **Hosting:** YouTube, Vimeo, GitHub (small files)

---

## 📝 Caption Your Screenshots

Add descriptions under each image:

```markdown
### Resident Dashboard
![Resident Dashboard](screenshots/resident-dashboard.png)
*Quick access to emergency SOS alerts, active incidents, and hazard reporting*

### Analytics Dashboard
![Analytics](screenshots/analytics.png)
*Real-time data visualization with incident trends and response metrics*
```

---

## 🌟 Inspiration

Look at great README examples:

- [GitHub Explore](https://github.com/explore)
- [Awesome README](https://github.com/matiassingers/awesome-readme)
- Top GitHub projects in your tech stack

---

**Happy Screenshot Taking! 📸**

Remember: Great screenshots make your project more approachable and help users understand what you've built before they even clone the repo!
