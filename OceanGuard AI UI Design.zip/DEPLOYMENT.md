# 🚀 Deployment Guide

This guide will help you deploy OceanGuard AI to various hosting platforms.

---

## 📋 Pre-Deployment Checklist

Before deploying, ensure:
- [ ] All tests pass locally
- [ ] Build completes successfully (`pnpm build`)
- [ ] Environment variables are configured
- [ ] Update the repository URL in `package.json`

---

## 🌐 Deployment Options

### 1. Vercel (Recommended)

**One-Click Deploy:**

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/oceanguard-ai)

**Manual Deploy:**

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Deploy to production
vercel --prod
```

**Configuration:**
- Framework Preset: Vite
- Build Command: `pnpm build`
- Output Directory: `dist`
- Install Command: `pnpm install`

---

### 2. Netlify

**Deploy via Git:**

1. Push code to GitHub
2. Go to [Netlify](https://netlify.com)
3. Click "New site from Git"
4. Connect your repository
5. Configure build settings:
   - Build command: `pnpm build`
   - Publish directory: `dist`

**Deploy via CLI:**

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build the project
pnpm build

# Deploy
netlify deploy

# Deploy to production
netlify deploy --prod
```

---

### 3. GitHub Pages

**Using GitHub Actions:**

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18'
      
      - name: Install pnpm
        uses: pnpm/action-setup@v2
        with:
          version: 8
      
      - name: Install dependencies
        run: pnpm install
      
      - name: Build
        run: pnpm build
      
      - name: Setup Pages
        uses: actions/configure-pages@v4
      
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: './dist'
      
      - name: Deploy to GitHub Pages
        uses: actions/deploy-pages@v4
```

**Manual Deploy:**

```bash
# Install gh-pages
pnpm add -D gh-pages

# Add to package.json scripts:
# "deploy": "gh-pages -d dist"

# Build and deploy
pnpm build
pnpm deploy
```

---

### 4. Cloudflare Pages

1. Push code to GitHub
2. Go to [Cloudflare Pages](https://pages.cloudflare.com/)
3. Create a new project
4. Connect your Git repository
5. Configure build:
   - Framework preset: Vite
   - Build command: `pnpm build`
   - Build output directory: `dist`

---

### 5. Railway

```bash
# Install Railway CLI
npm i -g @railway/cli

# Login
railway login

# Initialize project
railway init

# Deploy
railway up
```

---

## 🔧 Build Optimization

### Environment Variables

Create `.env.production`:

```env
VITE_API_URL=your-api-url
VITE_MAPS_API_KEY=your-maps-key
```

### Performance Tips

1. **Enable compression** in your hosting platform
2. **Configure caching headers** for static assets
3. **Use CDN** for faster global delivery
4. **Enable HTTP/2** for better performance

### Build Size Optimization

```bash
# Analyze bundle size
pnpm build
npx vite-bundle-visualizer
```

---

## 🌍 Custom Domain

### Vercel
1. Go to Project Settings → Domains
2. Add your custom domain
3. Configure DNS records as shown

### Netlify
1. Go to Site Settings → Domain Management
2. Add custom domain
3. Configure DNS or Netlify DNS

### Cloudflare Pages
1. Go to Custom Domains
2. Add your domain
3. Update nameservers to Cloudflare

---

## 📊 Monitoring & Analytics

### Add Google Analytics

1. Install package:
```bash
pnpm add react-ga4
```

2. Initialize in `App.tsx`:
```tsx
import ReactGA from 'react-ga4';

ReactGA.initialize('YOUR_MEASUREMENT_ID');
```

### Error Tracking with Sentry

```bash
pnpm add @sentry/react
```

---

## 🔒 Security Headers

Add to your hosting platform:

```
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(self)
```

---

## 🧪 Testing Deployment

Before going live:

1. **Test locally:**
   ```bash
   pnpm build
   pnpm preview
   ```

2. **Check responsive design** on multiple devices
3. **Verify all routes** work correctly
4. **Test language switching**
5. **Validate performance** with Lighthouse

---

## 📝 Post-Deployment

- [ ] Test all features in production
- [ ] Monitor error logs
- [ ] Set up uptime monitoring
- [ ] Configure backups
- [ ] Update README with live URL

---

## 🆘 Troubleshooting

### Build Fails

```bash
# Clear cache and reinstall
rm -rf node_modules pnpm-lock.yaml
pnpm install
pnpm build
```

### 404 on Routes

Add a redirect rule (for SPAs):
- Netlify: Create `public/_redirects` with `/* /index.html 200`
- Vercel: Already handles this automatically

### Environment Variables Not Working

- Ensure variables start with `VITE_`
- Restart dev server after changes
- Check platform-specific env var settings

---

## 📧 Support

For deployment issues:
- Check hosting platform documentation
- Review build logs for errors
- Open an issue on GitHub

---

**Happy Deploying! 🎉**
