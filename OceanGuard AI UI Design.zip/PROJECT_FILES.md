# 📁 OceanGuard AI - Complete File List

This document provides an overview of all files in the project and their purposes.

---

## 📄 Root Configuration Files

| File | Purpose |
|------|---------|
| `package.json` | Project dependencies and scripts |
| `vite.config.ts` | Vite build configuration |
| `postcss.config.mjs` | PostCSS configuration for Tailwind |
| `.gitignore` | Git ignore rules for node_modules, build files, etc. |

---

## 📚 Documentation Files

| File | Description |
|------|-------------|
| `README.md` | Main project documentation and overview |
| `QUICK_START.md` | Fast setup guide (5 minutes) |
| `DEPLOYMENT.md` | Deployment instructions for various platforms |
| `CONTRIBUTING.md` | Guidelines for contributing to the project |
| `GITHUB_SETUP.md` | Step-by-step GitHub repository setup |
| `CHANGELOG.md` | Version history and release notes |
| `PROJECT_FILES.md` | This file - complete file listing |
| `LICENSE` | MIT License |
| `ATTRIBUTIONS.md` | Credits and attributions |

---

## 🎨 Styles (`/src/styles/`)

| File | Purpose |
|------|---------|
| `index.css` | Main CSS entry point |
| `tailwind.css` | Tailwind CSS imports |
| `theme.css` | Custom CSS variables and theme tokens |
| `animations.css` | Custom animation utilities |
| `fonts.css` | Font imports (Google Fonts, etc.) |

---

## ⚛️ React Application (`/src/app/`)

### Main Files

| File | Purpose |
|------|---------|
| `App.tsx` | Root application component |
| `routes.tsx` | React Router configuration |

---

## 📄 Pages (`/src/app/pages/`)

| File | Description |
|------|-------------|
| `LoginPage.tsx` | Login and role selection page |
| `ResidentDashboard.tsx` | Main dashboard for residents |
| `RescueDashboard.tsx` | Control panel for rescue teams |
| `ReportHazardPage.tsx` | Hazard reporting form |
| `MapPage.tsx` | Interactive map view |
| `AnalyticsPage.tsx` | Data analytics and insights |
| `SettingsPage.tsx` | User settings and preferences |
| `NotFoundPage.tsx` | 404 error page |

---

## 🧩 Components (`/src/app/components/`)

### Custom Components

| File | Purpose |
|------|---------|
| `SOSButton.tsx` | Emergency SOS alert button |
| `AlertsList.tsx` | Display list of active alerts |
| `IncidentCard.tsx` | Individual incident display card |
| `LanguageSelector.tsx` | Language switching dropdown |
| `LiveMap.tsx` | Interactive incident map |
| `RiskMeter.tsx` | Visual risk level indicator |
| `AICopilot.tsx` | AI assistant chatbot interface |

### UI Component Library (`/src/app/components/ui/`)

Base components built on Radix UI:

| File | Component Type |
|------|---------------|
| `accordion.tsx` | Collapsible sections |
| `alert-dialog.tsx` | Modal dialogs for alerts |
| `alert.tsx` | Inline alert messages |
| `aspect-ratio.tsx` | Maintain aspect ratios |
| `avatar.tsx` | User profile pictures |
| `badge.tsx` | Status badges |
| `breadcrumb.tsx` | Navigation breadcrumbs |
| `button.tsx` | Clickable buttons |
| `calendar.tsx` | Date picker calendar |
| `card.tsx` | Content cards |
| `carousel.tsx` | Image/content carousel |
| `chart.tsx` | Data visualization wrapper |
| `checkbox.tsx` | Checkbox inputs |
| `collapsible.tsx` | Expandable sections |
| `command.tsx` | Command palette |
| `context-menu.tsx` | Right-click menus |
| `dialog.tsx` | Modal dialogs |
| `drawer.tsx` | Side drawer panels |
| `dropdown-menu.tsx` | Dropdown menus |
| `form.tsx` | Form components |
| `hover-card.tsx` | Hover tooltips |
| `input.tsx` | Text inputs |
| `input-otp.tsx` | OTP input fields |
| `label.tsx` | Form labels |
| `menubar.tsx` | Application menu bar |
| `navigation-menu.tsx` | Navigation menus |
| `pagination.tsx` | Page navigation |
| `popover.tsx` | Floating popovers |
| `progress.tsx` | Progress bars |
| `radio-group.tsx` | Radio button groups |
| `resizable.tsx` | Resizable panels |
| `scroll-area.tsx` | Custom scrollbars |
| `select.tsx` | Select dropdowns |
| `separator.tsx` | Visual dividers |
| `sheet.tsx` | Side sheets |
| `sidebar.tsx` | Navigation sidebar |
| `skeleton.tsx` | Loading skeletons |
| `slider.tsx` | Range sliders |
| `sonner.tsx` | Toast notifications |
| `switch.tsx` | Toggle switches |
| `table.tsx` | Data tables |
| `tabs.tsx` | Tab navigation |
| `textarea.tsx` | Multi-line text inputs |
| `toggle.tsx` | Toggle buttons |
| `toggle-group.tsx` | Toggle button groups |
| `tooltip.tsx` | Hover tooltips |
| `use-mobile.ts` | Mobile detection hook |
| `utils.ts` | Utility functions |

### Figma Integration (`/src/app/components/figma/`)

| File | Purpose |
|------|---------|
| `ImageWithFallback.tsx` | Image component with error handling |

---

## 🔧 Context & State (`/src/app/context/`)

| File | Purpose |
|------|---------|
| `LanguageContext.tsx` | Global language state management |

---

## 📊 Data (`/src/app/data/`)

| File | Purpose |
|------|---------|
| `mockData.ts` | Sample incidents, alerts, and statistics |
| `translations.ts` | All UI text in 5 languages |

---

## 📦 Total File Count

### Breakdown by Category:

- **Documentation**: 9 files
- **Configuration**: 4 files
- **Styles**: 5 files
- **Pages**: 8 files
- **Custom Components**: 7 files
- **UI Components**: 50+ files
- **Context/State**: 1 file
- **Data**: 2 files

**Total: 85+ files**

---

## 🗂️ Directory Structure

```
oceanguard-ai/
│
├── 📚 Documentation
│   ├── README.md
│   ├── QUICK_START.md
│   ├── DEPLOYMENT.md
│   ├── CONTRIBUTING.md
│   ├── GITHUB_SETUP.md
│   ├── CHANGELOG.md
│   ├── PROJECT_FILES.md
│   ├── LICENSE
│   └── ATTRIBUTIONS.md
│
├── ⚙️ Configuration
│   ├── package.json
│   ├── vite.config.ts
│   ├── postcss.config.mjs
│   └── .gitignore
│
├── 📁 guidelines/
│   └── Guidelines.md
│
└── 📁 src/
    ├── 📁 styles/
    │   ├── index.css
    │   ├── tailwind.css
    │   ├── theme.css
    │   ├── animations.css
    │   └── fonts.css
    │
    └── 📁 app/
        ├── App.tsx
        ├── routes.tsx
        │
        ├── 📁 pages/
        │   ├── LoginPage.tsx
        │   ├── ResidentDashboard.tsx
        │   ├── RescueDashboard.tsx
        │   ├── ReportHazardPage.tsx
        │   ├── MapPage.tsx
        │   ├── AnalyticsPage.tsx
        │   ├── SettingsPage.tsx
        │   └── NotFoundPage.tsx
        │
        ├── 📁 components/
        │   ├── SOSButton.tsx
        │   ├── AlertsList.tsx
        │   ├── IncidentCard.tsx
        │   ├── LanguageSelector.tsx
        │   ├── LiveMap.tsx
        │   ├── RiskMeter.tsx
        │   ├── AICopilot.tsx
        │   │
        │   ├── 📁 ui/ (50+ components)
        │   └── 📁 figma/
        │       └── ImageWithFallback.tsx
        │
        ├── 📁 context/
        │   └── LanguageContext.tsx
        │
        └── 📁 data/
            ├── mockData.ts
            └── translations.ts
```

---

## 🎯 Key Files for Developers

If you're new to the project, start with these files:

1. **README.md** - Project overview
2. **QUICK_START.md** - Get running fast
3. **src/app/App.tsx** - Application entry point
4. **src/app/routes.tsx** - Page routing
5. **src/app/data/translations.ts** - Add/edit languages
6. **src/app/data/mockData.ts** - Sample data
7. **src/styles/theme.css** - Customize colors/theme

---

## 🔍 Finding Specific Features

| Feature | Primary Files |
|---------|--------------|
| **SOS Alert** | `SOSButton.tsx`, `ResidentDashboard.tsx` |
| **Hazard Reporting** | `ReportHazardPage.tsx` |
| **Incident Management** | `RescueDashboard.tsx`, `IncidentCard.tsx` |
| **Maps** | `MapPage.tsx`, `LiveMap.tsx` |
| **Analytics** | `AnalyticsPage.tsx` |
| **Language Switching** | `LanguageContext.tsx`, `LanguageSelector.tsx` |
| **AI Features** | `AICopilot.tsx` |
| **Styling** | `src/styles/theme.css`, `src/styles/animations.css` |

---

## 📝 Editing Guidelines

### To Add a New Page:
1. Create file in `/src/app/pages/`
2. Add route in `/src/app/routes.tsx`
3. Add translations in `/src/app/data/translations.ts`

### To Add a New Component:
1. Create file in `/src/app/components/`
2. Import where needed
3. Follow TypeScript typing conventions

### To Add a New Language:
1. Edit `/src/app/data/translations.ts`
2. Add language code and all translations
3. Update `LanguageSelector.tsx`

### To Change Theme:
1. Edit `/src/styles/theme.css`
2. Modify CSS custom properties
3. Update Tailwind classes if needed

---

## 🚀 Build Artifacts (Generated)

These are created when you run `pnpm build`:

```
dist/              # Production build
  ├── index.html   # Entry HTML
  ├── assets/      # Bundled JS/CSS
  └── ...
```

**Note:** The `dist/` folder is in `.gitignore` and won't be committed to Git.

---

## 🔐 Environment Files (Not Included)

If you need environment variables:

```bash
# Create these files (they're in .gitignore)
.env              # Base environment variables
.env.local        # Local overrides
.env.production   # Production settings
```

Example `.env`:
```
VITE_API_URL=https://api.example.com
VITE_MAPS_KEY=your_key_here
```

---

## 📦 Dependencies

All project dependencies are listed in `package.json`:

- **React 18.3** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS 4** - Styling
- **React Router 7** - Routing
- **50+ UI libraries** - See package.json

---

## ✅ File Checklist for GitHub

Before pushing to GitHub, ensure you have:

- [x] All source files
- [x] Documentation files
- [x] Configuration files
- [x] .gitignore
- [x] LICENSE
- [x] README.md
- [ ] Update YOUR_USERNAME in docs
- [ ] Add screenshots (optional)
- [ ] Test build process

---

## 🆘 Need Help?

- **Can't find a file?** Use your editor's search (Cmd/Ctrl + P)
- **Want to understand a component?** Check the comments in the file
- **Need to add a feature?** See [CONTRIBUTING.md](CONTRIBUTING.md)

---

**Last Updated:** April 17, 2026  
**Project Version:** 1.0.0
