# 🤝 Contributing to OceanGuard AI

Thank you for considering contributing to OceanGuard AI! This document provides guidelines for contributing to the project.

---

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Workflow](#development-workflow)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)

---

## 🤗 Code of Conduct

- Be respectful and inclusive
- Welcome newcomers and help them learn
- Focus on constructive feedback
- Prioritize the community and project goals

---

## 🚀 Getting Started

### 1. Fork the Repository

Click the "Fork" button at the top right of the repository page.

### 2. Clone Your Fork

```bash
git clone https://github.com/YOUR_USERNAME/oceanguard-ai.git
cd oceanguard-ai
```

### 3. Add Upstream Remote

```bash
git remote add upstream https://github.com/original-owner/oceanguard-ai.git
```

### 4. Install Dependencies

```bash
pnpm install
```

### 5. Create a Branch

```bash
git checkout -b feature/your-feature-name
```

---

## 💻 Development Workflow

### Running Locally

```bash
# Start development server
pnpm dev

# Build for production
pnpm build

# Preview production build
pnpm preview
```

### Project Structure

```
src/
├── app/
│   ├── components/   # Reusable components
│   ├── pages/        # Page components
│   ├── context/      # React Context
│   ├── data/         # Mock data & translations
│   └── routes.tsx    # Route configuration
└── styles/          # Global styles
```

---

## 📝 Coding Standards

### TypeScript

- Use TypeScript for all new files
- Define proper types and interfaces
- Avoid `any` type when possible

```typescript
// Good
interface User {
  id: string;
  name: string;
  role: 'resident' | 'rescue';
}

// Avoid
const user: any = {...};
```

### React Components

- Use functional components with hooks
- Implement proper prop typing
- Keep components focused and small

```tsx
interface ButtonProps {
  label: string;
  onClick: () => void;
  variant?: 'primary' | 'secondary';
}

export function Button({ label, onClick, variant = 'primary' }: ButtonProps) {
  return <button onClick={onClick}>{label}</button>;
}
```

### Styling

- Use Tailwind CSS utility classes
- Follow the existing design system
- Maintain responsive design

```tsx
// Good
<div className="flex items-center justify-between p-4 bg-blue-600">

// Avoid inline styles
<div style={{ display: 'flex', padding: '16px' }}>
```

### File Naming

- Components: `PascalCase.tsx` (e.g., `SOSButton.tsx`)
- Utilities: `camelCase.ts` (e.g., `formatDate.ts`)
- Styles: `kebab-case.css` (e.g., `animations.css`)

---

## 📜 Commit Guidelines

### Commit Message Format

```
type(scope): subject

body (optional)

footer (optional)
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

### Examples

```bash
feat(dashboard): add real-time incident updates

fix(map): resolve marker clustering issue

docs(readme): update installation instructions

style(button): improve hover animations
```

---

## 🔄 Pull Request Process

### 1. Update Your Branch

```bash
git fetch upstream
git rebase upstream/main
```

### 2. Push Changes

```bash
git push origin feature/your-feature-name
```

### 3. Create Pull Request

1. Go to the original repository
2. Click "New Pull Request"
3. Select your fork and branch
4. Fill out the PR template

### PR Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Tested locally
- [ ] Added/updated tests
- [ ] All tests pass

## Screenshots (if applicable)
Add screenshots here

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-reviewed the code
- [ ] Commented complex code sections
- [ ] Updated documentation
- [ ] No new warnings generated
```

### 4. Code Review

- Respond to feedback promptly
- Make requested changes
- Keep the PR focused on one feature/fix

### 5. Merge

Once approved, a maintainer will merge your PR.

---

## 🐛 Reporting Bugs

### Before Submitting

- Check existing issues
- Verify it's reproducible
- Collect relevant information

### Bug Report Template

```markdown
**Description**
Clear description of the bug

**Steps to Reproduce**
1. Go to '...'
2. Click on '...'
3. See error

**Expected Behavior**
What should happen

**Actual Behavior**
What actually happens

**Screenshots**
If applicable

**Environment**
- Browser: [e.g., Chrome 120]
- Device: [e.g., Desktop, Mobile]
- OS: [e.g., Windows 11]
```

---

## 💡 Feature Requests

### Feature Request Template

```markdown
**Problem**
What problem does this solve?

**Proposed Solution**
How would you solve it?

**Alternatives**
Other solutions considered

**Additional Context**
Any other relevant information
```

---

## 🌍 Translations

### Adding a New Language

1. Edit `src/app/data/translations.ts`
2. Add your language code and translations
3. Update language selector
4. Test all UI strings

```typescript
export const translations = {
  en: { /* English */ },
  hi: { /* Hindi */ },
  // Add new language
  fr: { 
    welcome: 'Bienvenue',
    // ... all keys
  }
};
```

---

## 🧪 Testing

### Manual Testing

- Test on multiple browsers
- Verify responsive design
- Check all user flows
- Test language switching

### Future: Automated Tests

We plan to add:
- Unit tests with Vitest
- Component tests with React Testing Library
- E2E tests with Playwright

---

## 📚 Resources

- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [React Router Docs](https://reactrouter.com)

---

## ❓ Questions?

- Open a discussion on GitHub
- Check existing issues and PRs
- Read the documentation

---

## 🙏 Thank You!

Your contributions help make OceanGuard AI better for everyone. We appreciate your time and effort!

---

**Happy Coding! 🌊**
